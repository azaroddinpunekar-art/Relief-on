import {useCallback, useEffect, useState} from 'react';
import {Navigation} from './components/Navigation';
import {useOnlineStatus} from './hooks/useOnlineStatus';
import {UI_STRINGS} from './lib/i18n';
import {triggerDailyWisdomNotification} from './lib/notifications';
import {
  loadBookmarks,
  loadContinueReading,
  loadHistory,
  loadPreferences,
  saveBookmarks,
  saveContinueReading,
  saveHistory,
  savePreferences,
} from './lib/userStorage';
import {BookmarksScreen} from './screens/BookmarksScreen';
import {GuidanceScreen} from './screens/GuidanceScreen';
import {HomeScreen} from './screens/HomeScreen';
import {ProfileScreen} from './screens/ProfileScreen';
import {ScripturesScreen} from './screens/ScripturesScreen';
import type {
  BookmarkItem,
  ContinueReadingPosition,
  GuidanceCategoryId,
  ReadingHistoryItem,
  ReaderTarget,
  ScriptureId,
  TabId,
  UserPreferences,
} from './types/scripture';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>('home');
  const [preferences, setPreferences] = useState<UserPreferences>(() => loadPreferences());
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>(() => loadBookmarks());
  const [history, setHistory] = useState<ReadingHistoryItem[]>(() => loadHistory());
  const [continueReading, setContinueReading] = useState<ContinueReadingPosition | null>(() =>
    loadContinueReading()
  );

  const [selectedScripture, setSelectedScripture] = useState<ScriptureId>('quran');
  const [readerTarget, setReaderTarget] = useState<ReaderTarget | null>(null);
  const [guidanceCategory, setGuidanceCategory] = useState<GuidanceCategoryId>('fear-anxiety');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const isOnline = useOnlineStatus();
  const t = UI_STRINGS[preferences.language];

  // Sync Tailwind .dark class on <html>
  useEffect(() => {
    const root = document.documentElement;
    if (preferences.theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    const metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) {
      metaTheme.setAttribute('content', preferences.theme === 'dark' ? '#111214' : '#F7F5F0');
    }
  }, [preferences.theme]);

  // Daily Wisdom schedule check (once per day when enabled and time reached)
  useEffect(() => {
    if (!preferences.dailyWisdomNotification) return;
    const todayKey = new Date().toISOString().slice(0, 10);
    const lastFired = localStorage.getItem('relief_last_wisdom_notified');
    if (lastFired === todayKey) return;

    const [hh, mm] = preferences.notificationTime.split(':').map(Number);
    const now = new Date();
    const targetMinutes = (hh || 7) * 60 + (mm || 30);
    const nowMinutes = now.getHours() * 60 + now.getMinutes();

    if (nowMinutes >= targetMinutes) {
      localStorage.setItem('relief_last_wisdom_notified', todayKey);
      void triggerDailyWisdomNotification(preferences.language);
    }
  }, [preferences.dailyWisdomNotification, preferences.notificationTime, preferences.language]);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
  }, []);

  useEffect(() => {
    if (!toastMessage) return;
    const timer = setTimeout(() => setToastMessage(null), 3200);
    return () => clearTimeout(timer);
  }, [toastMessage]);

  const updatePreferences = useCallback((patch: Partial<UserPreferences>) => {
    setPreferences(prev => {
      const next = {...prev, ...patch};
      savePreferences(next);
      return next;
    });
  }, []);

  const toggleLanguage = useCallback(() => {
    updatePreferences({language: preferences.language === 'en' ? 'hi' : 'en'});
  }, [preferences.language, updatePreferences]);

  const isBookmarked = useCallback(
    (scripture: ScriptureId, chapter: number, verse: number) => {
      const id = `${scripture}:${chapter}:${verse}`;
      return bookmarks.some(b => b.id === id);
    },
    [bookmarks]
  );

  const toggleBookmark = useCallback(
    (scripture: ScriptureId, chapter: number, verse: number) => {
      const id = `${scripture}:${chapter}:${verse}`;
      setBookmarks(prev => {
        const exists = prev.some(b => b.id === id);
        const next = exists
          ? prev.filter(b => b.id !== id)
          : [{id, scripture, chapter, verse, createdAt: Date.now()}, ...prev];
        saveBookmarks(next);
        return next;
      });
    },
    []
  );

  const removeBookmark = useCallback((id: string) => {
    setBookmarks(prev => {
      const next = prev.filter(b => b.id !== id);
      saveBookmarks(next);
      return next;
    });
  }, []);

  const updateBookmarkNote = useCallback((id: string, note: string) => {
    setBookmarks(prev => {
      const next = prev.map(b => (b.id === id ? {...b, note} : b));
      saveBookmarks(next);
      return next;
    });
  }, []);

  const recordRead = useCallback(
    (scripture: ScriptureId, chapter: number, verse: number, chapterTitle: string) => {
      const pos: ContinueReadingPosition = {
        scripture,
        chapter,
        verse,
        chapterTitle,
        updatedAt: Date.now(),
      };
      setContinueReading(pos);
      saveContinueReading(pos);

      const entryId = `${scripture}:${chapter}:${verse}`;
      setHistory(prev => {
        const filtered = prev.filter(item => item.id !== entryId);
        const next: ReadingHistoryItem[] = [
          {
            id: entryId,
            scripture,
            chapter,
            verse,
            chapterTitle,
            timestamp: Date.now(),
          },
          ...filtered,
        ].slice(0, 40);
        saveHistory(next);
        return next;
      });
    },
    []
  );

  const clearHistory = useCallback(() => {
    setHistory([]);
    saveHistory([]);
  }, []);

  const openReader = useCallback((target: ReaderTarget) => {
    setSelectedScripture(target.scripture);
    setReaderTarget(target);
    setActiveTab('scriptures');
    window.scrollTo({top: 0, behavior: 'smooth'});
  }, []);

  const openScriptureIndex = useCallback((scripture: ScriptureId) => {
    setSelectedScripture(scripture);
    setReaderTarget(null);
    setActiveTab('scriptures');
    window.scrollTo({top: 0, behavior: 'smooth'});
  }, []);

  const openGuidance = useCallback((categoryId?: GuidanceCategoryId) => {
    if (categoryId) setGuidanceCategory(categoryId);
    setActiveTab('guidance');
    window.scrollTo({top: 0, behavior: 'smooth'});
  }, []);

  const handleSelectTab = useCallback((tab: TabId) => {
    setActiveTab(tab);
    window.scrollTo({top: 0, behavior: 'smooth'});
  }, []);

  return (
    <div className="min-h-screen bg-[#F7F5F0] text-[#1C1B18] dark:bg-[#111214] dark:text-[#ECE8DF] transition-colors">
      <Navigation
        activeTab={activeTab}
        onSelectTab={handleSelectTab}
        language={preferences.language}
        onToggleLanguage={toggleLanguage}
      />

      {!isOnline && (
        <div className="bg-[#8F6F38] dark:bg-[#C9A96E] text-white dark:text-[#111214] text-xs font-medium text-center py-1.5 px-4">
          {t.offlineIndicator}
        </div>
      )}

      <main className="max-w-6xl mx-auto px-4 md:px-6 pt-6 pb-24 md:pb-12">
        {activeTab === 'home' && (
          <HomeScreen
            language={preferences.language}
            displayName={preferences.displayName}
            continueReading={continueReading}
            bookmarks={bookmarks}
            history={history}
            isBookmarked={isBookmarked}
            onToggleBookmark={toggleBookmark}
            onOpenReader={openReader}
            onOpenScriptureIndex={openScriptureIndex}
            onOpenGuidance={openGuidance}
            onNavigateTab={handleSelectTab}
            onShowToast={showToast}
          />
        )}

        {activeTab === 'scriptures' && (
          <ScripturesScreen
            language={preferences.language}
            textSize={preferences.textSize}
            selectedScripture={selectedScripture}
            activeTarget={readerTarget}
            onChangeScripture={setSelectedScripture}
            onChangeLanguage={lang => updatePreferences({language: lang})}
            onChangeTextSize={sz => updatePreferences({textSize: sz})}
            onOpenTarget={setReaderTarget}
            onRecordRead={recordRead}
            isBookmarked={isBookmarked}
            onToggleBookmark={toggleBookmark}
            onShowToast={showToast}
          />
        )}

        {activeTab === 'guidance' && (
          <GuidanceScreen
            language={preferences.language}
            selectedCategoryId={guidanceCategory}
            onSelectCategory={setGuidanceCategory}
            onOpenReader={openReader}
            isBookmarked={isBookmarked}
            onToggleBookmark={toggleBookmark}
            onShowToast={showToast}
          />
        )}

        {activeTab === 'bookmarks' && (
          <BookmarksScreen
            language={preferences.language}
            bookmarks={bookmarks}
            history={history}
            onRemoveBookmark={removeBookmark}
            onUpdateBookmarkNote={updateBookmarkNote}
            onClearHistory={clearHistory}
            onOpenReader={openReader}
            onShowToast={showToast}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileScreen
            preferences={preferences}
            onUpdatePreferences={updatePreferences}
            onShowToast={showToast}
          />
        )}
      </main>

      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-50 max-w-md w-[calc(100%-2rem)] rounded-xl bg-[#1C1B18] dark:bg-[#ECE8DF] text-[#F7F5F0] dark:text-[#111214] px-4 py-3 text-xs sm:text-sm font-medium shadow-lg text-center"
        >
          {toastMessage}
        </div>
      )}
    </div>
  );
}
