import type {LanguageCode} from '../types/scripture';

export const UI_STRINGS: Record<LanguageCode, {
  appTagline: string;
  welcomeTitle: string;
  welcomeBody: string;
  navHome: string;
  navScriptures: string;
  navGuidance: string;
  navBookmarks: string;
  navProfile: string;
  continueReading: string;
  resumeAt: string;
  openReader: string;
  startReading: string;
  holyQuran: string;
  bhagavadGita: string;
  quranMeta: string;
  gitaMeta: string;
  dailyWisdom: string;
  nextWisdom: string;
  prevWisdom: string;
  exploreGuidance: string;
  viewAllCategories: string;
  recentlyRead: string;
  bookmarkedVerses: string;
  noRecentReading: string;
  noBookmarksYet: string;
  searchPlaceholder: string;
  allScriptures: string;
  surahLabel: string;
  chapterLabel: string;
  verseLabel: string;
  versesCountLabel: string;
  jumpToVerse: string;
  goLabel: string;
  previous: string;
  next: string;
  backToIndex: string;
  bookmark: string;
  bookmarked: string;
  share: string;
  copiedNotice: string;
  scriptureQuotation: string;
  explanatoryReflection: string;
  guidanceDisclaimer: string;
  quranPerspective: string;
  gitaPerspective: string;
  savedVersesTab: string;
  readingHistoryTab: string;
  clearHistory: string;
  addNotePlaceholder: string;
  saveNote: string;
  languageSetting: string;
  appearanceSetting: string;
  darkTheme: string;
  lightTheme: string;
  textSizeSetting: string;
  dailyNotificationSetting: string;
  testNotification: string;
  offlineLibrarySetting: string;
  downloadOffline: string;
  offlineReady: string;
  clearOffline: string;
  readerProfile: string;
  displayNameLabel: string;
  offlineIndicator: string;
  loadingScriptures: string;
  searchResultsLabel: string;
  noSearchResults: string;
}> = {
  en: {
    appTagline: 'Scriptural clarity & quiet reflection',
    welcomeTitle: 'Find steadiness, clarity, and gentle wisdom.',
    welcomeBody: 'Read complete English and Hindi translations of the Holy Quran and the Bhagavad Gita side by side with life-situation guidance.',
    navHome: 'Home',
    navScriptures: 'Scriptures',
    navGuidance: 'Guidance',
    navBookmarks: 'Bookmarks',
    navProfile: 'Profile',
    continueReading: 'Continue Reading',
    resumeAt: 'Resume at',
    openReader: 'Resume',
    startReading: 'Begin Reading',
    holyQuran: 'Holy Quran',
    bhagavadGita: 'Bhagavad Gita',
    quranMeta: '114 Surahs · 6,236 Verses',
    gitaMeta: '18 Chapters · 700 Verses',
    dailyWisdom: 'Daily Wisdom',
    nextWisdom: 'Next',
    prevWisdom: 'Previous',
    exploreGuidance: 'Explore Guidance',
    viewAllCategories: 'All 10 Situations',
    recentlyRead: 'Recently Read',
    bookmarkedVerses: 'Bookmarked Verses',
    noRecentReading: 'Your reading trail appears here once you open a Surah or Chapter.',
    noBookmarksYet: 'Bookmark any verse while reading to keep it close for quiet reflection.',
    searchPlaceholder: 'Search Surah, chapter, 2:255, or keywords...',
    allScriptures: 'Both Scriptures',
    surahLabel: 'Surah',
    chapterLabel: 'Chapter',
    verseLabel: 'Verse',
    versesCountLabel: 'verses',
    jumpToVerse: 'Verse #',
    goLabel: 'Go',
    previous: 'Previous',
    next: 'Next',
    backToIndex: 'All Chapters',
    bookmark: 'Bookmark',
    bookmarked: 'Saved',
    share: 'Share',
    copiedNotice: 'Verse reference and text copied to clipboard.',
    scriptureQuotation: 'Scripture Quotation',
    explanatoryReflection: 'Explanatory Reflection',
    guidanceDisclaimer: 'References from the Holy Quran and the Bhagavad Gita are presented separately in their own theological contexts.',
    quranPerspective: 'From the Holy Quran',
    gitaPerspective: 'From the Bhagavad Gita',
    savedVersesTab: 'Saved Verses',
    readingHistoryTab: 'Reading History',
    clearHistory: 'Clear History',
    addNotePlaceholder: 'Add a quiet personal reflection...',
    saveNote: 'Save Note',
    languageSetting: 'Reading Language',
    appearanceSetting: 'Theme',
    darkTheme: 'Dark Charcoal & Gold',
    lightTheme: 'Warm Stone Light',
    textSizeSetting: 'Reading Text Size',
    dailyNotificationSetting: 'Daily Wisdom Reminder',
    testNotification: 'Send Preview',
    offlineLibrarySetting: 'Offline Scripture Cache',
    downloadOffline: 'Download Both Scriptures for Offline',
    offlineReady: 'Verified & Cached Offline',
    clearOffline: 'Clear Cache',
    readerProfile: 'Reader Preferences',
    displayNameLabel: 'Reader Name',
    offlineIndicator: 'Offline Mode · Reading from local scripture cache',
    loadingScriptures: 'Loading verified scripture texts...',
    searchResultsLabel: 'Search Results',
    noSearchResults: 'No matching verses found. Try a keyword, Surah/Chapter name, or reference like 2:47.',
  },
  hi: {
    appTagline: 'पवित्र ग्रंथों का शांत अध्ययन एवं मार्गदर्शन',
    welcomeTitle: 'मन की शांति, स्पष्टता और जीवन-दृष्टि प्राप्त करें।',
    welcomeBody: 'पवित्र क़ुरआन और भगवद गीता के संपूर्ण हिंदी और अंग्रेज़ी अनुवाद तथा जीवन की परिस्थितियों पर आधारित प्रामाणिक मार्गदर्शन पढ़ें।',
    navHome: 'होम',
    navScriptures: 'ग्रंथ',
    navGuidance: 'मार्गदर्शन',
    navBookmarks: 'बुकमार्क',
    navProfile: 'प्रोफ़ाइल',
    continueReading: 'पढ़ना जारी रखें',
    resumeAt: 'यहाँ से जारी रखें',
    openReader: 'आगे पढ़ें',
    startReading: 'पढ़ना शुरू करें',
    holyQuran: 'पवित्र क़ुरआन',
    bhagavadGita: 'भगवद गीता',
    quranMeta: '114 सूरह · 6,236 आयतें',
    gitaMeta: '18 अध्याय · 700 श्लोक',
    dailyWisdom: 'दैनिक ज्ञान',
    nextWisdom: 'अगला',
    prevWisdom: 'पिछला',
    exploreGuidance: 'जीवन मार्गदर्शन',
    viewAllCategories: 'सभी 10 विषय',
    recentlyRead: 'हाल ही में पढ़ा गया',
    bookmarkedVerses: 'सहेजी गई आयतें एवं श्लोक',
    noRecentReading: 'किसी सूरह या अध्याय को खोलने पर आपका पठन इतिहास यहाँ दिखाई देगा।',
    noBookmarksYet: 'पढ़ते समय किसी भी आयत या श्लोक को सहेजने के लिए बुकमार्क चुनें।',
    searchPlaceholder: 'सूरह, अध्याय, 2:255 या शब्द खोजें...',
    allScriptures: 'दोनों ग्रंथ',
    surahLabel: 'सूरह',
    chapterLabel: 'अध्याय',
    verseLabel: 'आयत / श्लोक',
    versesCountLabel: 'पद',
    jumpToVerse: 'संख्या',
    goLabel: 'जाएं',
    previous: 'पिछला',
    next: 'अगला',
    backToIndex: 'सभी अध्याय',
    bookmark: 'बुकमार्क',
    bookmarked: 'सहेजा गया',
    share: 'साझा करें',
    copiedNotice: 'आयत/श्लोक संदर्भ सहित कॉपी हो गया है।',
    scriptureQuotation: 'मूल ग्रंथ उद्धरण',
    explanatoryReflection: 'व्याख्यात्मक चिंतन',
    guidanceDisclaimer: 'पवित्र क़ुरआन और भगवद गीता के संदर्भ उनके अपने स्वतंत्र संदर्भ में अलग-अलग प्रस्तुत किए गए हैं।',
    quranPerspective: 'पवित्र क़ुरआन से',
    gitaPerspective: 'भगवद गीता से',
    savedVersesTab: 'सहेजे गए पद',
    readingHistoryTab: 'पठन इतिहास',
    clearHistory: 'इतिहास मिटाएँ',
    addNotePlaceholder: 'अपना व्यक्तिगत चिंतन लिखें...',
    saveNote: 'नोट सहेजें',
    languageSetting: 'पठन भाषा',
    appearanceSetting: 'थीम',
    darkTheme: 'डार्क चारकोल एवं गोल्ड',
    lightTheme: 'सौम्य लाइट थीम',
    textSizeSetting: 'अक्षर का आकार',
    dailyNotificationSetting: 'दैनिक ज्ञान सूचना',
    testNotification: 'पूर्वावलोकन भेजें',
    offlineLibrarySetting: 'ऑफ़लाइन ग्रंथ संग्रह',
    downloadOffline: 'ऑफ़लाइन पढ़ने के लिए दोनों ग्रंथ डाउनलोड करें',
    offlineReady: 'सत्यापित एवं ऑफ़लाइन सहेजा गया',
    clearOffline: 'कैश साफ़ करें',
    readerProfile: 'पाठक प्राथमिकताएँ',
    displayNameLabel: 'पाठक का नाम',
    offlineIndicator: 'ऑफ़लाइन मोड · स्थानीय कैश से पढ़ा जा रहा है',
    loadingScriptures: 'सत्यापित ग्रंथ लोड हो रहे हैं...',
    searchResultsLabel: 'खोज परिणाम',
    noSearchResults: 'कोई मिलता हुआ पद नहीं मिला। कोई शब्द, सूरह/अध्याय या 2:47 जैसा संदर्भ लिखें।',
  },
};
