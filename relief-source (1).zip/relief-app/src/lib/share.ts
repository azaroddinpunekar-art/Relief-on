import type {LanguageCode, ScriptureId} from '../types/scripture';

export async function shareVerse(params: {
  scripture: ScriptureId;
  chapter: number;
  verse: number;
  chapterTitle: string;
  text: string;
  language: LanguageCode;
}): Promise<'shared' | 'copied' | 'failed'> {
  const scriptureName =
    params.scripture === 'quran'
      ? params.language === 'hi'
        ? 'पवित्र क़ुरआन'
        : 'Holy Quran'
      : params.language === 'hi'
        ? 'भगवद गीता'
        : 'Bhagavad Gita';

  const formatted = `"${params.text}"\n\n— ${scriptureName} ${params.chapter}:${params.verse} (${params.chapterTitle})\nvia RELIEF`;

  if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
    try {
      await navigator.share({
        title: `${scriptureName} ${params.chapter}:${params.verse}`,
        text: formatted,
      });
      return 'shared';
    } catch (err) {
      if (err instanceof Error && err.name === 'AbortError') {
        return 'failed';
      }
    }
  }

  if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(formatted);
      return 'copied';
    } catch {
      return 'failed';
    }
  }

  return 'failed';
}
