import {DAILY_WISDOM_SEEDS, getDailyWisdomIndex} from '../data/dailyWisdom';
import {getSingleVerse} from './scriptureStore';
import type {LanguageCode} from '../types/scripture';

export async function requestWisdomNotificationPermission(): Promise<'granted' | 'denied' | 'unsupported'> {
  if (typeof Notification === 'undefined') {
    return 'unsupported';
  }
  if (Notification.permission === 'granted') {
    return 'granted';
  }
  if (Notification.permission === 'denied') {
    return 'denied';
  }
  const result = await Notification.requestPermission();
  return result === 'granted' ? 'granted' : 'denied';
}

export async function triggerDailyWisdomNotification(lang: LanguageCode): Promise<{
  delivered: boolean;
  title: string;
  body: string;
}> {
  const seed = DAILY_WISDOM_SEEDS[getDailyWisdomIndex(0)];
  const verse = await getSingleVerse(seed.scripture, seed.chapter, seed.verse, lang);
  const scriptureName =
    seed.scripture === 'quran'
      ? lang === 'hi'
        ? 'पवित्र क़ुरआन'
        : 'Holy Quran'
      : lang === 'hi'
        ? 'भगवद गीता'
        : 'Bhagavad Gita';

  const title = `RELIEF · ${scriptureName} ${seed.chapter}:${seed.verse}`;
  const body = verse ? verse.text : lang === 'hi' ? seed.reflectionHi : seed.reflectionEn;

  if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
    try {
      new Notification(title, {
        body,
        icon: '/pwa-192x192.png',
        badge: '/pwa-192x192.png',
      });
      return {delivered: true, title, body};
    } catch {
      return {delivered: false, title, body};
    }
  }
  return {delivered: false, title, body};
}
