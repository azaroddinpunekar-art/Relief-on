import type {
  GitaChapter,
  GitaVerseRecord,
  LanguageCode,
  OfflineStatus,
  QuranSurah,
  QuranVerseRecord,
  ScriptureId,
  ScriptureVerseView,
  SearchResultItem,
} from '../types/scripture';

const DB_NAME = 'relief_scriptures_db';
const DB_VERSION = 1;
const STORE_NAME = 'datasets';

type DatasetKey =
  | 'quran_surahs'
  | 'quran_en'
  | 'quran_hi'
  | 'gita_chapters'
  | 'gita_en'
  | 'gita_hi'
  | 'meta_status';

interface MemoryCache {
  quranSurahs?: QuranSurah[];
  quranEn?: QuranVerseRecord[];
  quranHi?: QuranVerseRecord[];
  gitaChapters?: GitaChapter[];
  gitaEn?: GitaVerseRecord[];
  gitaHi?: GitaVerseRecord[];
}

const mem: MemoryCache = {};
const inflight: Partial<Record<DatasetKey, Promise<unknown>>> = {};

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB unavailable'));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function idbGet<T>(key: DatasetKey): Promise<T | null> {
  try {
    const db = await openDb();
    return await new Promise<T | null>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const req = tx.objectStore(STORE_NAME).get(key);
      req.onsuccess = () => resolve((req.result as T) ?? null);
      req.onerror = () => reject(req.error);
    });
  } catch {
    return null;
  }
}

async function idbSet<T>(key: DatasetKey, value: T): Promise<void> {
  try {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const req = tx.objectStore(STORE_NAME).put(value, key);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch {
    // Graceful degradation when IndexedDB is restricted
  }
}

async function idbClear(): Promise<void> {
  try {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const req = tx.objectStore(STORE_NAME).clear();
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch {
    // ignore
  }
}

async function loadDataset<T>(key: DatasetKey, url: string, memField: keyof MemoryCache): Promise<T> {
  if (mem[memField]) {
    return mem[memField] as unknown as T;
  }
  if (inflight[key]) {
    return inflight[key] as Promise<T>;
  }

  const promise = (async () => {
    const cached = await idbGet<T>(key);
    if (cached) {
      mem[memField] = cached as never;
      return cached;
    }
    const resp = await fetch(url);
    if (!resp.ok) {
      throw new Error(`Failed to load ${url} (${resp.status})`);
    }
    const data = (await resp.json()) as T;
    mem[memField] = data as never;
    await idbSet(key, data);
    return data;
  })();

  inflight[key] = promise;
  try {
    return await promise;
  } finally {
    delete inflight[key];
  }
}

export async function getQuranSurahs(): Promise<QuranSurah[]> {
  return loadDataset<QuranSurah[]>('quran_surahs', '/data/quran_surahs.json', 'quranSurahs');
}

export async function getQuranVerses(lang: LanguageCode): Promise<QuranVerseRecord[]> {
  return lang === 'hi'
    ? loadDataset<QuranVerseRecord[]>('quran_hi', '/data/quran_hi.json', 'quranHi')
    : loadDataset<QuranVerseRecord[]>('quran_en', '/data/quran_en.json', 'quranEn');
}

export async function getGitaChapters(): Promise<GitaChapter[]> {
  return loadDataset<GitaChapter[]>('gita_chapters', '/data/gita_chapters.json', 'gitaChapters');
}

export async function getGitaVerses(lang: LanguageCode): Promise<GitaVerseRecord[]> {
  return lang === 'hi'
    ? loadDataset<GitaVerseRecord[]>('gita_hi', '/data/gita_hi.json', 'gitaHi')
    : loadDataset<GitaVerseRecord[]>('gita_en', '/data/gita_en.json', 'gitaEn');
}

export async function getChapterVerses(
  scripture: ScriptureId,
  chapter: number,
  lang: LanguageCode
): Promise<{chapterTitle: string; verses: ScriptureVerseView[]}> {
  if (scripture === 'quran') {
    const [surahs, allVerses] = await Promise.all([getQuranSurahs(), getQuranVerses(lang)]);
    const surah = surahs.find(s => s.number === chapter);
    const title = surah ? `${surah.name} (${surah.englishName})` : `Surah ${chapter}`;
    const filtered = allVerses
      .filter(v => v.s === chapter)
      .map(v => ({
        scripture: 'quran' as const,
        chapter: v.s,
        verse: v.v,
        chapterTitle: title,
        text: v.t,
        language: lang,
      }));
    return {chapterTitle: title, verses: filtered};
  }

  const [chapters, allVerses] = await Promise.all([getGitaChapters(), getGitaVerses(lang)]);
  const chap = chapters.find(c => c.number === chapter);
  const title = chap ? `${chap.nameTransliterated} (${chap.nameMeaningEn})` : `Chapter ${chapter}`;
  const filtered = allVerses
    .filter(v => v.c === chapter)
    .map(v => ({
      scripture: 'gita' as const,
      chapter: v.c,
      verse: v.v,
      chapterTitle: title,
      text: v.t,
      language: lang,
    }));
  return {chapterTitle: title, verses: filtered};
}

export async function getSingleVerse(
  scripture: ScriptureId,
  chapter: number,
  verse: number,
  lang: LanguageCode
): Promise<ScriptureVerseView | null> {
  if (scripture === 'quran') {
    const [surahs, allVerses] = await Promise.all([getQuranSurahs(), getQuranVerses(lang)]);
    const surah = surahs.find(s => s.number === chapter);
    const found = allVerses.find(v => v.s === chapter && v.v === verse);
    if (!found) return null;
    return {
      scripture: 'quran',
      chapter,
      verse,
      chapterTitle: surah ? `${surah.name} (${surah.englishName})` : `Surah ${chapter}`,
      text: found.t,
      language: lang,
    };
  }

  const [chapters, allVerses] = await Promise.all([getGitaChapters(), getGitaVerses(lang)]);
  const chap = chapters.find(c => c.number === chapter);
  const found = allVerses.find(v => v.c === chapter && v.v === verse);
  if (!found) return null;
  return {
    scripture: 'gita',
    chapter,
    verse,
    chapterTitle: chap ? `${chap.nameTransliterated} (${chap.nameMeaningEn})` : `Chapter ${chapter}`,
    text: found.t,
    language: lang,
  };
}

export async function searchScriptures(
  query: string,
  filterScripture: 'all' | ScriptureId,
  lang: LanguageCode,
  limit = 60
): Promise<SearchResultItem[]> {
  const q = query.trim();
  if (!q) return [];

  const lower = q.toLowerCase();
  const refMatch = q.match(/^(\d{1,3})\s*[:.]\s*(\d{1,3})$/);
  const numericOnly = q.match(/^(\d{1,3})$/);

  const results: SearchResultItem[] = [];

  if (filterScripture === 'all' || filterScripture === 'quran') {
    const [surahs, qVerses] = await Promise.all([getQuranSurahs(), getQuranVerses(lang)]);
    const surahMap = new Map(surahs.map(s => [s.number, `${s.name} (${s.englishName})`]));

    if (refMatch) {
      const sNum = Number(refMatch[1]);
      const vNum = Number(refMatch[2]);
      const exact = qVerses.find(v => v.s === sNum && v.v === vNum);
      if (exact) {
        results.push({
          scripture: 'quran',
          chapter: exact.s,
          verse: exact.v,
          chapterTitle: surahMap.get(exact.s) || `Surah ${exact.s}`,
          text: exact.t,
          language: lang,
          matchType: 'reference',
        });
      }
    } else if (numericOnly) {
      const num = Number(numericOnly[1]);
      if (num >= 1 && num <= 114) {
        const firstVerse = qVerses.find(v => v.s === num && v.v === 1);
        if (firstVerse) {
          results.push({
            scripture: 'quran',
            chapter: firstVerse.s,
            verse: firstVerse.v,
            chapterTitle: surahMap.get(firstVerse.s) || `Surah ${firstVerse.s}`,
            text: firstVerse.t,
            language: lang,
            matchType: 'chapter',
          });
        }
      }
    } else {
      // Match surah names first
      for (const s of surahs) {
        if (
          s.name.toLowerCase().includes(lower) ||
          s.englishName.toLowerCase().includes(lower)
        ) {
          const first = qVerses.find(v => v.s === s.number && v.v === 1);
          if (first) {
            results.push({
              scripture: 'quran',
              chapter: first.s,
              verse: first.v,
              chapterTitle: surahMap.get(first.s) || s.name,
              text: first.t,
              language: lang,
              matchType: 'chapter',
            });
          }
        }
      }

      // Keyword search in verse text
      for (const v of qVerses) {
        if (results.length >= limit) break;
        if (v.t.toLowerCase().includes(lower)) {
          results.push({
            scripture: 'quran',
            chapter: v.s,
            verse: v.v,
            chapterTitle: surahMap.get(v.s) || `Surah ${v.s}`,
            text: v.t,
            language: lang,
            matchType: 'keyword',
          });
        }
      }
    }
  }

  if (filterScripture === 'all' || filterScripture === 'gita') {
    const [chapters, gVerses] = await Promise.all([getGitaChapters(), getGitaVerses(lang)]);
    const chapMap = new Map(chapters.map(c => [c.number, `${c.nameTransliterated} (${c.nameMeaningEn})`]));

    if (refMatch) {
      const cNum = Number(refMatch[1]);
      const vNum = Number(refMatch[2]);
      const exact = gVerses.find(v => v.c === cNum && v.v === vNum);
      if (exact) {
        results.push({
          scripture: 'gita',
          chapter: exact.c,
          verse: exact.v,
          chapterTitle: chapMap.get(exact.c) || `Chapter ${exact.c}`,
          text: exact.t,
          language: lang,
          matchType: 'reference',
        });
      }
    } else if (numericOnly) {
      const num = Number(numericOnly[1]);
      if (num >= 1 && num <= 18) {
        const firstVerse = gVerses.find(v => v.c === num && v.v === 1);
        if (firstVerse) {
          results.push({
            scripture: 'gita',
            chapter: firstVerse.c,
            verse: firstVerse.v,
            chapterTitle: chapMap.get(firstVerse.c) || `Chapter ${firstVerse.c}`,
            text: firstVerse.t,
            language: lang,
            matchType: 'chapter',
          });
        }
      }
    } else {
      for (const c of chapters) {
        if (
          c.nameTransliterated.toLowerCase().includes(lower) ||
          c.nameMeaningEn.toLowerCase().includes(lower)
        ) {
          const first = gVerses.find(v => v.c === c.number && v.v === 1);
          if (first) {
            results.push({
              scripture: 'gita',
              chapter: first.c,
              verse: first.v,
              chapterTitle: chapMap.get(first.c) || c.nameTransliterated,
              text: first.t,
              language: lang,
              matchType: 'chapter',
            });
          }
        }
      }

      for (const v of gVerses) {
        if (results.length >= limit) break;
        if (v.t.toLowerCase().includes(lower)) {
          results.push({
            scripture: 'gita',
            chapter: v.c,
            verse: v.v,
            chapterTitle: chapMap.get(v.c) || `Chapter ${v.c}`,
            text: v.t,
            language: lang,
            matchType: 'keyword',
          });
        }
      }
    }
  }

  return results.slice(0, limit);
}

export async function downloadAllForOffline(): Promise<OfflineStatus> {
  const [surahs, qEn, qHi, chapters, gEn, gHi] = await Promise.all([
    getQuranSurahs(),
    getQuranVerses('en'),
    getQuranVerses('hi'),
    getGitaChapters(),
    getGitaVerses('en'),
    getGitaVerses('hi'),
  ]);

  const status: OfflineStatus = {
    quranCached: surahs.length === 114 && qEn.length === 6236 && qHi.length === 6236,
    gitaCached: chapters.length === 18 && gEn.length === 700 && gHi.length === 700,
    lastSyncedAt: Date.now(),
    quranSurahCount: surahs.length,
    quranVerseCount: qEn.length,
    gitaChapterCount: chapters.length,
    gitaVerseCount: gEn.length,
  };
  await idbSet('meta_status', status);
  return status;
}

export async function getOfflineStatus(): Promise<OfflineStatus> {
  const saved = await idbGet<OfflineStatus>('meta_status');
  if (saved) return saved;
  const [qEn, qHi, gEn, gHi] = await Promise.all([
    idbGet<QuranVerseRecord[]>('quran_en'),
    idbGet<QuranVerseRecord[]>('quran_hi'),
    idbGet<GitaVerseRecord[]>('gita_en'),
    idbGet<GitaVerseRecord[]>('gita_hi'),
  ]);
  return {
    quranCached: Boolean(qEn && qHi && qEn.length === 6236 && qHi.length === 6236),
    gitaCached: Boolean(gEn && gHi && gEn.length === 700 && gHi.length === 700),
    lastSyncedAt: null,
    quranSurahCount: qEn ? 114 : 0,
    quranVerseCount: qEn?.length ?? 0,
    gitaChapterCount: gEn ? 18 : 0,
    gitaVerseCount: gEn?.length ?? 0,
  };
}

export async function clearOfflineCache(): Promise<void> {
  delete mem.quranSurahs;
  delete mem.quranEn;
  delete mem.quranHi;
  delete mem.gitaChapters;
  delete mem.gitaEn;
  delete mem.gitaHi;
  await idbClear();
}
