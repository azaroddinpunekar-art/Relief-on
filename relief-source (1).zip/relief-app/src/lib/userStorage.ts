import type {
  BookmarkItem,
  ContinueReadingPosition,
  ReadingHistoryItem,
  UserPreferences,
} from '../types/scripture';

const PREFS_KEY = 'relief_preferences_v1';
const BOOKMARKS_KEY = 'relief_bookmarks_v1';
const HISTORY_KEY = 'relief_history_v1';
const CONTINUE_KEY = 'relief_continue_v1';

export const DEFAULT_PREFERENCES: UserPreferences = {
  language: 'en',
  theme: 'dark',
  textSize: 'md',
  dailyWisdomNotification: false,
  notificationTime: '07:30',
  displayName: 'Seeker',
};

function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJson<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // ignore storage quota edge cases
  }
}

export function loadPreferences(): UserPreferences {
  const saved = readJson<Partial<UserPreferences>>(PREFS_KEY, {});
  return {
    language: saved.language === 'hi' ? 'hi' : 'en',
    theme: saved.theme === 'light' ? 'light' : 'dark',
    textSize:
      saved.textSize === 'sm' ||
      saved.textSize === 'md' ||
      saved.textSize === 'lg' ||
      saved.textSize === 'xl'
        ? saved.textSize
        : 'md',
    dailyWisdomNotification: Boolean(saved.dailyWisdomNotification),
    notificationTime: typeof saved.notificationTime === 'string' ? saved.notificationTime : '07:30',
    displayName: typeof saved.displayName === 'string' && saved.displayName.trim() ? saved.displayName : 'Seeker',
  };
}

export function savePreferences(prefs: UserPreferences): void {
  writeJson(PREFS_KEY, prefs);
}

export function loadBookmarks(): BookmarkItem[] {
  const items = readJson<BookmarkItem[]>(BOOKMARKS_KEY, []);
  return Array.isArray(items) ? items : [];
}

export function saveBookmarks(items: BookmarkItem[]): void {
  writeJson(BOOKMARKS_KEY, items);
}

export function loadHistory(): ReadingHistoryItem[] {
  const items = readJson<ReadingHistoryItem[]>(HISTORY_KEY, []);
  return Array.isArray(items) ? items : [];
}

export function saveHistory(items: ReadingHistoryItem[]): void {
  writeJson(HISTORY_KEY, items.slice(0, 40));
}

export function loadContinueReading(): ContinueReadingPosition | null {
  return readJson<ContinueReadingPosition | null>(CONTINUE_KEY, null);
}

export function saveContinueReading(pos: ContinueReadingPosition): void {
  writeJson(CONTINUE_KEY, pos);
}
