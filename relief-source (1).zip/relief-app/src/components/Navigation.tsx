import React from 'react';
import {Bookmark, BookOpen, Compass, Home, User} from 'lucide-react';
import type {LanguageCode, TabId} from '../types/scripture';
import {UI_STRINGS} from '../lib/i18n';

interface NavigationProps {
  activeTab: TabId;
  onSelectTab: (tab: TabId) => void;
  language: LanguageCode;
  onToggleLanguage: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onSelectTab,
  language,
  onToggleLanguage,
}) => {
  const t = UI_STRINGS[language];

  const items: {id: TabId; label: string; icon: React.ComponentType<{className?: string}>}[] = [
    {id: 'home', label: t.navHome, icon: Home},
    {id: 'scriptures', label: t.navScriptures, icon: BookOpen},
    {id: 'guidance', label: t.navGuidance, icon: Compass},
    {id: 'bookmarks', label: t.navBookmarks, icon: Bookmark},
    {id: 'profile', label: t.navProfile, icon: User},
  ];

  return (
    <>
      {/* Top Bar: 3-zone contract on desktop, compact 2-item bar on mobile */}
      <header className="sticky top-0 z-30 h-14 md:h-16 bg-[#F7F5F0]/90 dark:bg-[#111214]/90 backdrop-blur-md border-b border-[#E3DDD1] dark:border-[#24252A]">
        <div className="max-w-6xl mx-auto h-full px-4 md:px-6 flex items-center justify-between gap-8">
          {/* Zone 1: Single wordmark */}
          <button
            type="button"
            onClick={() => onSelectTab('home')}
            className="font-display text-xl md:text-2xl font-semibold tracking-[0.14em] text-[#1C1B18] dark:text-[#ECE8DF] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C9A96E] rounded"
          >
            RELIEF
          </button>

          {/* Zone 2: Desktop 5 single-line nav links */}
          <nav aria-label="Primary Navigation" className="hidden md:flex items-center gap-7">
            {items.map(item => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onSelectTab(item.id)}
                  className={`relative py-2 text-sm font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C9A96E] rounded ${
                    isActive
                      ? 'text-[#8F6F38] dark:text-[#C9A96E]'
                      : 'text-[#5C5850] dark:text-[#A8A39A] hover:text-[#1C1B18] dark:hover:text-[#ECE8DF]'
                  }`}
                >
                  {item.label}
                  {isActive && (
                    <span
                      aria-hidden="true"
                      className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#8F6F38] dark:bg-[#C9A96E]"
                    />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Single primary language action */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={onToggleLanguage}
              aria-label={language === 'en' ? 'Switch reading language to Hindi' : 'Switch reading language to English'}
              className="min-h-[40px] px-3.5 py-1.5 rounded-lg border border-[#D8D1C5] dark:border-[#2C2D33] text-xs font-medium text-[#1C1B18] dark:text-[#ECE8DF] hover:border-[#8F6F38] dark:hover:border-[#C9A96E] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {language === 'en' ? 'English · हिंदी' : 'हिंदी · English'}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Fixed Bottom 5-Tab Bar */}
      <nav
        aria-label="Mobile Bottom Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#F7F5F0]/95 dark:bg-[#141518]/95 backdrop-blur-md border-t border-[#E3DDD1] dark:border-[#24252A] pb-safe"
      >
        <div className="grid grid-cols-5 h-16 items-center">
          {items.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectTab(item.id)}
                className={`min-h-[48px] flex flex-col items-center justify-center gap-1 px-1 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[#C9A96E] ${
                  isActive
                    ? 'text-[#8F6F38] dark:text-[#C9A96E]'
                    : 'text-[#6B665D] dark:text-[#8E8A82] hover:text-[#1C1B18] dark:hover:text-[#ECE8DF]'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.2]' : 'stroke-[1.75]'}`} />
                <span className="text-[11px] font-medium tracking-tight whitespace-nowrap truncate max-w-full">
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
};
