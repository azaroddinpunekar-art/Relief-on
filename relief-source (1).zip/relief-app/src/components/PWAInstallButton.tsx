import React, {useState} from 'react';
import {Download, Smartphone} from 'lucide-react';
import {usePWAInstall} from '../hooks/usePWAInstall';
import type {LanguageCode} from '../types/scripture';

interface PWAInstallButtonProps {
  language: LanguageCode;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({language}) => {
  const {isInstallable, isInstalled, isIOS, install} = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) {
    return (
      <span className="text-xs text-[#8F6F38] dark:text-[#C9A96E] font-medium">
        {language === 'hi' ? 'ऐप इंस्टॉल है' : 'Installed on device'}
      </span>
    );
  }

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={() => void install()}
        className="inline-flex items-center justify-center gap-2 min-h-[44px] px-5 py-2.5 rounded-xl bg-[#8F6F38] dark:bg-[#C9A96E] text-white dark:text-[#111214] text-sm font-semibold hover:opacity-90 transition-opacity whitespace-nowrap shrink-0 cursor-pointer"
      >
        <Download className="w-4 h-4" />
        <span>{language === 'hi' ? 'RELIEF ऐप इंस्टॉल करें' : 'Install RELIEF App'}</span>
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowIOSGuide(true)}
          className="inline-flex items-center justify-center gap-2 min-h-[44px] px-4 py-2 rounded-xl border border-[#D8D1C5] dark:border-[#2C2D33] text-sm font-medium text-[#1C1B18] dark:text-[#ECE8DF] hover:bg-black/5 dark:hover:bg-white/5 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Smartphone className="w-4 h-4" />
          <span>{language === 'hi' ? 'होम स्क्रीन पर जोड़ें' : 'Add to Home Screen'}</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
            <div className="w-full max-w-sm rounded-2xl bg-[#F7F5F0] dark:bg-[#18191D] border border-[#E5DEC9] dark:border-[#2A2B31] p-6">
              <h3 className="font-display text-xl font-semibold text-[#1C1B18] dark:text-[#ECE8DF]">
                {language === 'hi' ? 'iPhone / iPad पर इंस्टॉल करें' : 'Install on iPhone or iPad'}
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-[#5C5850] dark:text-[#A8A39A]">
                {language === 'hi'
                  ? '1. Safari टूलबार में Share बटन दबाएं। 2. नीचे स्क्रॉल करें और Add to Home Screen चुनें।'
                  : '1. Tap the Share button in Safari toolbar. 2. Scroll down and tap Add to Home Screen.'}
              </p>
              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 w-full min-h-[44px] rounded-xl bg-[#8F6F38] dark:bg-[#C9A96E] text-white dark:text-[#111214] text-sm font-semibold cursor-pointer"
              >
                {language === 'hi' ? 'बंद करें' : 'Close'}
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return (
    <span className="text-xs text-[#6B665D] dark:text-[#8E8A82]">
      {language === 'hi'
        ? 'Chrome / Android मेनू से "Install App" चुनकर इंस्टॉल करें'
        : 'Use browser menu ("Add to Home Screen" / "Install App") on Android'}
    </span>
  );
};
