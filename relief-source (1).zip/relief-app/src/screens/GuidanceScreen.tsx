import React, {useEffect, useState} from 'react';
import {ArrowRight, Bookmark, ChevronRight, Share2} from 'lucide-react';
import {GUIDANCE_CATEGORIES} from '../data/guidance';
import {UI_STRINGS} from '../lib/i18n';
import {getSingleVerse} from '../lib/scriptureStore';
import {shareVerse} from '../lib/share';
import type {
  GuidanceCategoryId,
  GuidanceReference,
  LanguageCode,
  ReaderTarget,
  ScriptureId,
  ScriptureVerseView,
} from '../types/scripture';

interface GuidanceScreenProps {
  language: LanguageCode;
  selectedCategoryId: GuidanceCategoryId;
  onSelectCategory: (id: GuidanceCategoryId) => void;
  onOpenReader: (target: ReaderTarget) => void;
  isBookmarked: (scripture: ScriptureId, chapter: number, verse: number) => boolean;
  onToggleBookmark: (scripture: ScriptureId, chapter: number, verse: number) => void;
  onShowToast: (msg: string) => void;
}

interface HydratedRef extends GuidanceReference {
  verseData: ScriptureVerseView | null;
}

export const GuidanceScreen: React.FC<GuidanceScreenProps> = ({
  language,
  selectedCategoryId,
  onSelectCategory,
  onOpenReader,
  isBookmarked,
  onToggleBookmark,
  onShowToast,
}) => {
  const t = UI_STRINGS[language];
  const activeCategory =
    GUIDANCE_CATEGORIES.find(c => c.id === selectedCategoryId) ?? GUIDANCE_CATEGORIES[0];

  const [quranItems, setQuranItems] = useState<HydratedRef[]>([]);
  const [gitaItems, setGitaItems] = useState<HydratedRef[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    setLoading(true);
    Promise.all([
      Promise.all(
        activeCategory.quranRefs.map(async ref => ({
          ...ref,
          verseData: await getSingleVerse('quran', ref.chapter, ref.verse, language),
        }))
      ),
      Promise.all(
        activeCategory.gitaRefs.map(async ref => ({
          ...ref,
          verseData: await getSingleVerse('gita', ref.chapter, ref.verse, language),
        }))
      ),
    ])
      .then(([qRes, gRes]) => {
        if (!active) return;
        setQuranItems(qRes);
        setGitaItems(gRes);
        setLoading(false);
      })
      .catch(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [activeCategory, language]);

  const handleShare = async (verseData: ScriptureVerseView | null) => {
    if (!verseData) return;
    const res = await shareVerse(verseData);
    if (res === 'copied') onShowToast(t.copiedNotice);
  };

  const renderPerspectiveCard = (
    scripture: ScriptureId,
    item: HydratedRef
  ) => {
    const saved = isBookmarked(scripture, item.chapter, item.verse);
    return (
      <article
        key={`${scripture}:${item.chapter}:${item.verse}`}
        className="rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] p-5 sm:p-6 space-y-4"
      >
        <div className="flex items-center justify-between gap-3 text-xs text-[#6B665D] dark:text-[#8E8A82]">
          <span className="font-semibold text-[#8F6F38] dark:text-[#C9A96E] tabular-nums">
            {scripture === 'quran' ? t.holyQuran : t.bhagavadGita} · {item.chapter}:{item.verse}
          </span>
          {item.verseData && <span className="truncate">{item.verseData.chapterTitle}</span>}
        </div>

        {/* Clearly separated Scripture Quotation */}
        <div className="space-y-1.5">
          <p className="text-[11px] font-medium tracking-wide text-[#6B665D] dark:text-[#8E8A82]">
            {t.scriptureQuotation}
          </p>
          <blockquote className="text-base leading-relaxed text-[#1C1B18] dark:text-[#ECE8DF]">
            {item.verseData ? `“${item.verseData.text}”` : t.loadingScriptures}
          </blockquote>
        </div>

        {/* Clearly separated Explanatory Reflection */}
        <div className="pt-3 border-t border-[#ECE7DC] dark:border-[#24252A] space-y-1.5">
          <p className="text-[11px] font-medium tracking-wide text-[#8F6F38] dark:text-[#C9A96E]">
            {t.explanatoryReflection}
          </p>
          <p className="text-sm text-[#5C5850] dark:text-[#A8A39A] leading-relaxed">
            {language === 'hi' ? item.reflectionHi : item.reflectionEn}
          </p>
        </div>

        <div className="pt-2 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => onToggleBookmark(scripture, item.chapter, item.verse)}
              className={`min-h-[40px] px-3 rounded-lg border text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer ${
                saved
                  ? 'border-[#8F6F38] dark:border-[#C9A96E] text-[#8F6F38] dark:text-[#C9A96E]'
                  : 'border-[#E3DDD1] dark:border-[#2A2B32] text-[#5C5850] dark:text-[#A8A39A]'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5" />
              <span>{saved ? t.bookmarked : t.bookmark}</span>
            </button>
            <button
              type="button"
              onClick={() => void handleShare(item.verseData)}
              className="min-h-[40px] px-3 rounded-lg border border-[#E3DDD1] dark:border-[#2A2B32] text-xs font-medium text-[#5C5850] dark:text-[#A8A39A] inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>{t.share}</span>
            </button>
          </div>

          <button
            type="button"
            onClick={() =>
              onOpenReader({
                scripture,
                chapter: item.chapter,
                verse: item.verse,
              })
            }
            className="min-h-[40px] px-3.5 rounded-lg text-xs font-semibold text-[#8F6F38] dark:text-[#C9A96E] hover:underline inline-flex items-center gap-1 cursor-pointer"
          >
            <span>{t.openReader}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </article>
    );
  };

  return (
    <div className="space-y-6 pb-8">
      <div className="space-y-2">
        <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#1C1B18] dark:text-[#ECE8DF]">
          {t.exploreGuidance}
        </h1>
        <p className="text-sm text-[#6B665D] dark:text-[#8E8A82] max-w-3xl">
          {t.guidanceDisclaimer}
        </p>
      </div>

      {/* All 10 Life Situation Categories */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
        {GUIDANCE_CATEGORIES.map(cat => {
          const active = cat.id === activeCategory.id;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => onSelectCategory(cat.id)}
              className={`min-h-[48px] px-3.5 py-2.5 rounded-xl border text-left transition-colors flex items-center justify-between gap-2 cursor-pointer ${
                active
                  ? 'bg-[#8F6F38] dark:bg-[#C9A96E] border-[#8F6F38] dark:border-[#C9A96E] text-white dark:text-[#111214]'
                  : 'bg-white dark:bg-[#17181C] border-[#E3DDD1] dark:border-[#24252A] text-[#1C1B18] dark:text-[#ECE8DF] hover:border-[#8F6F38] dark:hover:border-[#C9A96E]/60'
              }`}
            >
              <span className="text-xs sm:text-sm font-medium truncate">
                {language === 'hi' ? cat.titleHi : cat.titleEn}
              </span>
              <ChevronRight className={`w-3.5 h-3.5 shrink-0 ${active ? 'opacity-90' : 'opacity-40'}`} />
            </button>
          );
        })}
      </div>

      {/* Active Category Header */}
      <div className="pt-2 border-t border-[#E3DDD1] dark:border-[#24252A] space-y-1">
        <h2 className="font-display text-2xl sm:text-3xl font-semibold text-[#1C1B18] dark:text-[#ECE8DF]">
          {language === 'hi' ? activeCategory.titleHi : activeCategory.titleEn}
        </h2>
        <p className="text-sm text-[#5C5850] dark:text-[#A8A39A]">
          {language === 'hi' ? activeCategory.subtitleHi : activeCategory.subtitleEn}
        </p>
      </div>

      {loading ? (
        <div className="py-12 text-center text-sm text-[#6B665D] dark:text-[#8E8A82]">
          {t.loadingScriptures}
        </div>
      ) : (
        /* Separate Quran & Bhagavad Gita Columns */
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
          <section aria-labelledby="quran-guidance-heading" className="space-y-4">
            <h3
              id="quran-guidance-heading"
              className="font-display text-xl sm:text-2xl font-semibold text-[#8F6F38] dark:text-[#C9A96E]"
            >
              {t.quranPerspective}
            </h3>
            <div className="space-y-4">
              {quranItems.map(item => renderPerspectiveCard('quran', item))}
            </div>
          </section>

          <section aria-labelledby="gita-guidance-heading" className="space-y-4">
            <h3
              id="gita-guidance-heading"
              className="font-display text-xl sm:text-2xl font-semibold text-[#8F6F38] dark:text-[#C9A96E]"
            >
              {t.gitaPerspective}
            </h3>
            <div className="space-y-4">
              {gitaItems.map(item => renderPerspectiveCard('gita', item))}
            </div>
          </section>
        </div>
      )}
    </div>
  );
};
