import React, {useEffect, useState} from 'react';
import {Bell, CheckCircle2, Database, Moon, Sun, Trash2} from 'lucide-react';
import {PWAInstallButton} from '../components/PWAInstallButton';
import {UI_STRINGS} from '../lib/i18n';
import {
  requestWisdomNotificationPermission,
  triggerDailyWisdomNotification,
} from '../lib/notifications';
import {
  clearOfflineCache,
  downloadAllForOffline,
  getOfflineStatus,
} from '../lib/scriptureStore';
import type {
  LanguageCode,
  OfflineStatus,
  TextSizeOption,
  ThemeMode,
  UserPreferences,
} from '../types/scripture';

interface ProfileScreenProps {
  preferences: UserPreferences;
  onUpdatePreferences: (patch: Partial<UserPreferences>) => void;
  onShowToast: (msg: string) => void;
}

const PREVIEW_SIZE_CLASS: Record<TextSizeOption, string> = {
  sm: 'text-sm leading-relaxed',
  md: 'text-base leading-[1.75]',
  lg: 'text-lg leading-[1.8]',
  xl: 'text-xl leading-[1.85]',
};

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  preferences,
  onUpdatePreferences,
  onShowToast,
}) => {
  const t = UI_STRINGS[preferences.language];
  const [offlineStatus, setOfflineStatus] = useState<OfflineStatus | null>(null);
  const [downloadingOffline, setDownloadingOffline] = useState(false);

  useEffect(() => {
    getOfflineStatus()
      .then(setOfflineStatus)
      .catch(() => setOfflineStatus(null));
  }, []);

  const handleToggleNotification = async () => {
    const next = !preferences.dailyWisdomNotification;
    if (next) {
      const perm = await requestWisdomNotificationPermission();
      onUpdatePreferences({dailyWisdomNotification: true});
      if (perm === 'granted') {
        onShowToast(
          preferences.language === 'hi'
            ? 'दैनिक ज्ञान सूचना सक्रिय हो गई है।'
            : 'Daily wisdom reminders enabled.'
        );
      } else {
        onShowToast(
          preferences.language === 'hi'
            ? 'सूचना प्राथमिकता सहेजी गई (इन-ऐप रिमाइंडर सक्रिय)।'
            : 'Reminder preference saved (in-app wisdom active).'
        );
      }
    } else {
      onUpdatePreferences({dailyWisdomNotification: false});
    }
  };

  const handleSendTestNotification = async () => {
    const res = await triggerDailyWisdomNotification(preferences.language);
    if (res.delivered) {
      onShowToast(
        preferences.language === 'hi'
          ? 'दैनिक ज्ञान सूचना भेजी गई।'
          : 'Daily wisdom notification sent.'
      );
    } else {
      onShowToast(`${res.title} — ${res.body.slice(0, 90)}`);
    }
  };

  const handleDownloadOffline = async () => {
    setDownloadingOffline(true);
    try {
      const status = await downloadAllForOffline();
      setOfflineStatus(status);
      onShowToast(
        preferences.language === 'hi'
          ? 'दोनों ग्रंथ ऑफ़लाइन पढ़ने के लिए सहेजे गए।'
          : 'Both scriptures verified and cached for offline reading.'
      );
    } catch {
      onShowToast('Unable to download offline cache right now.');
    } finally {
      setDownloadingOffline(false);
    }
  };

  const handleClearOffline = async () => {
    await clearOfflineCache();
    const status = await getOfflineStatus();
    setOfflineStatus(status);
    onShowToast(
      preferences.language === 'hi' ? 'ऑफ़लाइन कैश साफ़ किया गया।' : 'Offline cache cleared.'
    );
  };

  const isFullyCached = Boolean(offlineStatus?.quranCached && offlineStatus?.gitaCached);

  return (
    <div className="space-y-6 pb-8">
      <div>
        <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#1C1B18] dark:text-[#ECE8DF]">
          {t.readerProfile}
        </h1>
        <p className="text-sm text-[#6B665D] dark:text-[#8E8A82] mt-1">
          {t.holyQuran} · {t.bhagavadGita}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Display Name & Reading Language */}
        <section className="rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] p-6 space-y-5">
          <div className="space-y-2">
            <label
              htmlFor="relief-display-name"
              className="block text-xs font-medium text-[#6B665D] dark:text-[#8E8A82]"
            >
              {t.displayNameLabel}
            </label>
            <input
              id="relief-display-name"
              type="text"
              maxLength={40}
              value={preferences.displayName}
              onChange={e => onUpdatePreferences({displayName: e.target.value})}
              className="w-full min-h-[44px] px-3.5 rounded-xl bg-[#F7F5F0] dark:bg-[#111214] border border-[#D8D1C5] dark:border-[#2A2B32] text-sm text-[#1C1B18] dark:text-[#ECE8DF] focus:outline-none focus:border-[#8F6F38] dark:focus:border-[#C9A96E]"
            />
          </div>

          <div className="space-y-2 pt-2 border-t border-[#ECE7DC] dark:border-[#24252A]">
            <p className="text-xs font-medium text-[#6B665D] dark:text-[#8E8A82]">
              {t.languageSetting}
            </p>
            <div className="grid grid-cols-2 gap-2.5">
              {([
                {code: 'en', label: 'English'},
                {code: 'hi', label: 'हिंदी (Hindi)'},
              ] as {code: LanguageCode; label: string}[]).map(opt => {
                const active = preferences.language === opt.code;
                return (
                  <button
                    key={opt.code}
                    type="button"
                    onClick={() => onUpdatePreferences({language: opt.code})}
                    className={`min-h-[46px] px-4 rounded-xl border text-sm font-medium transition-colors cursor-pointer ${
                      active
                        ? 'bg-[#8F6F38] dark:bg-[#C9A96E] border-[#8F6F38] dark:border-[#C9A96E] text-white dark:text-[#111214]'
                        : 'bg-[#F7F5F0] dark:bg-[#111214] border-[#E3DDD1] dark:border-[#24252A] text-[#1C1B18] dark:text-[#ECE8DF]'
                    }`}
                  >
                    {opt.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Theme */}
          <div className="space-y-2 pt-2 border-t border-[#ECE7DC] dark:border-[#24252A]">
            <p className="text-xs font-medium text-[#6B665D] dark:text-[#8E8A82]">
              {t.appearanceSetting}
            </p>
            <div className="grid grid-cols-2 gap-2.5">
              {([
                {mode: 'dark', label: t.darkTheme, icon: Moon},
                {mode: 'light', label: t.lightTheme, icon: Sun},
              ] as {mode: ThemeMode; label: string; icon: React.ComponentType<{className?: string}>}[]).map(
                opt => {
                  const Icon = opt.icon;
                  const active = preferences.theme === opt.mode;
                  return (
                    <button
                      key={opt.mode}
                      type="button"
                      onClick={() => onUpdatePreferences({theme: opt.mode})}
                      className={`min-h-[46px] px-3.5 rounded-xl border text-xs sm:text-sm font-medium inline-flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                        active
                          ? 'bg-[#8F6F38] dark:bg-[#C9A96E] border-[#8F6F38] dark:border-[#C9A96E] text-white dark:text-[#111214]'
                          : 'bg-[#F7F5F0] dark:bg-[#111214] border-[#E3DDD1] dark:border-[#24252A] text-[#1C1B18] dark:text-[#ECE8DF]'
                      }`}
                    >
                      <Icon className="w-4 h-4 shrink-0" />
                      <span className="truncate">{opt.label}</span>
                    </button>
                  );
                }
              )}
            </div>
          </div>
        </section>

        {/* Adjustable Text Size */}
        <section className="rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] p-6 space-y-4">
          <div className="flex items-center justify-between gap-4">
            <p className="text-xs font-medium text-[#6B665D] dark:text-[#8E8A82]">
              {t.textSizeSetting}
            </p>
            <div className="inline-flex items-center p-1 rounded-xl bg-[#F7F5F0] dark:bg-[#111214] border border-[#E3DDD1] dark:border-[#24252A]">
              {(['sm', 'md', 'lg', 'xl'] as TextSizeOption[]).map(sz => (
                <button
                  key={sz}
                  type="button"
                  onClick={() => onUpdatePreferences({textSize: sz})}
                  className={`min-h-[38px] min-w-[40px] px-2.5 rounded-lg text-xs font-semibold uppercase transition-colors cursor-pointer ${
                    preferences.textSize === sz
                      ? 'bg-white dark:bg-[#23242A] text-[#8F6F38] dark:text-[#C9A96E] shadow-sm'
                      : 'text-[#6B665D] dark:text-[#8E8A82]'
                  }`}
                >
                  {sz}
                </button>
              ))}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#F7F5F0] dark:bg-[#111214] border border-[#E3DDD1] dark:border-[#24252A]">
            <p className="text-xs text-[#8F6F38] dark:text-[#C9A96E] mb-1.5 tabular-nums">
              {preferences.language === 'hi' ? 'पवित्र क़ुरआन · 94:5' : 'Holy Quran · 94:5'}
            </p>
            <p className={`text-[#1C1B18] dark:text-[#ECE8DF] ${PREVIEW_SIZE_CLASS[preferences.textSize]}`}>
              {preferences.language === 'hi'
                ? 'निश्चय ही कठिनाई के साथ आसानी है।'
                : 'So, surely with hardship comes ease.'}
            </p>
          </div>

          {/* Daily Wisdom Notification */}
          <div className="pt-3 border-t border-[#ECE7DC] dark:border-[#24252A] space-y-3">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2.5">
                <Bell className="w-4 h-4 text-[#8F6F38] dark:text-[#C9A96E]" />
                <span className="text-sm font-medium text-[#1C1B18] dark:text-[#ECE8DF]">
                  {t.dailyNotificationSetting}
                </span>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={preferences.dailyWisdomNotification}
                onClick={() => void handleToggleNotification()}
                className={`min-h-[32px] w-12 rounded-full p-1 transition-colors cursor-pointer ${
                  preferences.dailyWisdomNotification
                    ? 'bg-[#8F6F38] dark:bg-[#C9A96E]'
                    : 'bg-[#D8D1C5] dark:bg-[#2C2D33]'
                }`}
              >
                <span
                  className={`block w-5 h-5 rounded-full bg-white dark:bg-[#111214] transition-transform ${
                    preferences.dailyWisdomNotification ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <input
                type="time"
                value={preferences.notificationTime}
                onChange={e => onUpdatePreferences({notificationTime: e.target.value})}
                className="min-h-[40px] px-3 rounded-xl bg-[#F7F5F0] dark:bg-[#111214] border border-[#D8D1C5] dark:border-[#2A2B32] text-sm text-[#1C1B18] dark:text-[#ECE8DF] tabular-nums"
              />
              <button
                type="button"
                onClick={() => void handleSendTestNotification()}
                className="min-h-[40px] px-3.5 rounded-xl border border-[#D8D1C5] dark:border-[#2C2D33] text-xs font-medium text-[#1C1B18] dark:text-[#ECE8DF] hover:border-[#8F6F38] dark:hover:border-[#C9A96E] cursor-pointer"
              >
                {t.testNotification}
              </button>
            </div>
          </div>
        </section>

        {/* Offline Scripture Cache */}
        <section className="rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] p-6 space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <Database className="w-4 h-4 text-[#8F6F38] dark:text-[#C9A96E]" />
              <h2 className="text-base font-semibold text-[#1C1B18] dark:text-[#ECE8DF]">
                {t.offlineLibrarySetting}
              </h2>
            </div>
            {isFullyCached && (
              <span className="inline-flex items-center gap-1 text-xs font-medium text-[#8F6F38] dark:text-[#C9A96E]">
                <CheckCircle2 className="w-4 h-4" />
                <span>{t.offlineReady}</span>
              </span>
            )}
          </div>

          <div className="text-xs text-[#5C5850] dark:text-[#A8A39A] space-y-1 tabular-nums">
            <p>
              {t.holyQuran}: {offlineStatus?.quranSurahCount || 114} Surahs ·{' '}
              {offlineStatus?.quranVerseCount || 6236} Verses (EN + HI)
            </p>
            <p>
              {t.bhagavadGita}: {offlineStatus?.gitaChapterCount || 18} Chapters ·{' '}
              {offlineStatus?.gitaVerseCount || 700} Verses (EN + HI)
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-1">
            <button
              type="button"
              disabled={downloadingOffline}
              onClick={() => void handleDownloadOffline()}
              className="min-h-[44px] px-4 rounded-xl bg-[#8F6F38] dark:bg-[#C9A96E] text-white dark:text-[#111214] text-xs sm:text-sm font-semibold disabled:opacity-60 cursor-pointer"
            >
              {downloadingOffline ? t.loadingScriptures : t.downloadOffline}
            </button>

            {isFullyCached && (
              <button
                type="button"
                onClick={() => void handleClearOffline()}
                className="min-h-[44px] px-3.5 rounded-xl border border-[#D8D1C5] dark:border-[#2C2D33] text-xs font-medium text-[#5C5850] dark:text-[#A8A39A] inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{t.clearOffline}</span>
              </button>
            )}
          </div>
        </section>

        {/* Android & PWA App Installation */}
        <section className="rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] p-6 space-y-4">
          <h2 className="text-base font-semibold text-[#1C1B18] dark:text-[#ECE8DF]">
            {preferences.language === 'hi' ? 'मोबाइल ऐप और इंस्टॉलेशन' : 'Mobile App & Android Access'}
          </h2>
          <p className="text-xs sm:text-sm text-[#5C5850] dark:text-[#A8A39A] leading-relaxed">
            {preferences.language === 'hi'
              ? 'RELIEF को अपने Android फ़ोन पर इंस्टॉल करें या Android APK बनाने के लिए पूरा प्रोजेक्ट ZIP डाउनलोड करें।'
              : 'Install RELIEF on your Android device for offline reading, or download the complete project ZIP to package an Android APK locally.'}
          </p>
          <div className="flex flex-wrap items-center gap-3">
            <PWAInstallButton language={preferences.language} />
            <a
              href="/relief-source.zip"
              download="relief-source.zip"
              className="inline-flex items-center justify-center min-h-[44px] px-4 py-2 rounded-xl border border-[#D8D1C5] dark:border-[#2C2D33] text-xs sm:text-sm font-medium text-[#1C1B18] dark:text-[#ECE8DF] hover:border-[#8F6F38] dark:hover:border-[#C9A96E] transition-colors whitespace-nowrap"
            >
              {preferences.language === 'hi' ? 'सोर्स कोड ZIP डाउनलोड करें' : 'Download Source ZIP'}
            </a>
          </div>
        </section>
      </div>
    </div>
  );
};
