import React, {useEffect, useMemo, useRef, useState} from 'react';
import {
  ArrowLeft,
  Bookmark,
  ChevronLeft,
  ChevronRight,
  Search,
  Share2,
  X,
} from 'lucide-react';
import {UI_STRINGS} from '../lib/i18n';
import {
  getChapterVerses,
  getGitaChapters,
  getQuranSurahs,
  searchScriptures,
} from '../lib/scriptureStore';
import {shareVerse} from '../lib/share';
import type {
  GitaChapter,
  LanguageCode,
  QuranSurah,
  ReaderTarget,
  ScriptureId,
  ScriptureVerseView,
  SearchResultItem,
  TextSizeOption,
} from '../types/scripture';

interface ScripturesScreenProps {
  language: LanguageCode;
  textSize: TextSizeOption;
  selectedScripture: ScriptureId;
  activeTarget: ReaderTarget | null;
  onChangeScripture: (scripture: ScriptureId) => void;
  onChangeLanguage: (lang: LanguageCode) => void;
  onChangeTextSize: (size: TextSizeOption) => void;
  onOpenTarget: (target: ReaderTarget | null) => void;
  onRecordRead: (scripture: ScriptureId, chapter: number, verse: number, chapterTitle: string) => void;
  isBookmarked: (scripture: ScriptureId, chapter: number, verse: number) => boolean;
  onToggleBookmark: (scripture: ScriptureId, chapter: number, verse: number) => void;
  onShowToast: (msg: string) => void;
}

const TEXT_SIZE_CLASSES: Record<TextSizeOption, string> = {
  sm: 'text-sm leading-relaxed',
  md: 'text-base leading-[1.75]',
  lg: 'text-lg leading-[1.8]',
  xl: 'text-xl leading-[1.85]',
};

export const ScripturesScreen: React.FC<ScripturesScreenProps> = ({
  language,
  textSize,
  selectedScripture,
  activeTarget,
  onChangeScripture,
  onChangeLanguage,
  onChangeTextSize,
  onOpenTarget,
  onRecordRead,
  isBookmarked,
  onToggleBookmark,
  onShowToast,
}) => {
  const t = UI_STRINGS[language];

  const [surahs, setSurahs] = useState<QuranSurah[]>([]);
  const [gitaChapters, setGitaChapters] = useState<GitaChapter[]>([]);
  const [indexLoading, setIndexLoading] = useState(true);

  const [searchQuery, setSearchQuery] = useState('');
  const [searchScope, setSearchScope] = useState<'all' | ScriptureId>('all');
  const [searchResults, setSearchResults] = useState<SearchResultItem[]>([]);
  const [searching, setSearching] = useState(false);

  const [readerTitle, setReaderTitle] = useState('');
  const [readerVerses, setReaderVerses] = useState<ScriptureVerseView[]>([]);
  const [readerLoading, setReaderLoading] = useState(false);
  const [jumpInput, setJumpInput] = useState('');
  const [highlightedVerse, setHighlightedVerse] = useState<number | null>(null);

  const verseRefs = useRef<Record<number, HTMLDivElement | null>>({});

  // Load Surah (114) and Chapter (18) indices
  useEffect(() => {
    let active = true;
    setIndexLoading(true);
    Promise.all([getQuranSurahs(), getGitaChapters()])
      .then(([qList, gList]) => {
        if (!active) return;
        setSurahs(qList);
        setGitaChapters(gList);
        setIndexLoading(false);
      })
      .catch(() => {
        if (active) setIndexLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  // Search handler (debounced)
  useEffect(() => {
    const trimmed = searchQuery.trim();
    if (!trimmed) {
      setSearchResults([]);
      setSearching(false);
      return;
    }

    let active = true;
    setSearching(true);
    const timer = setTimeout(() => {
      searchScriptures(trimmed, searchScope, language, 60)
        .then(res => {
          if (active) {
            setSearchResults(res);
            setSearching(false);
          }
        })
        .catch(() => {
          if (active) {
            setSearchResults([]);
            setSearching(false);
          }
        });
    }, 180);

    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [searchQuery, searchScope, language]);

  // Load chapter verses when activeTarget is set
  useEffect(() => {
    if (!activeTarget) return;
    let active = true;
    setReaderLoading(true);
    setHighlightedVerse(activeTarget.verse ?? null);

    getChapterVerses(activeTarget.scripture, activeTarget.chapter, language)
      .then(({chapterTitle, verses}) => {
        if (!active) return;
        setReaderTitle(chapterTitle);
        setReaderVerses(verses);
        setReaderLoading(false);
        const targetVerse = activeTarget.verse ?? 1;
        onRecordRead(activeTarget.scripture, activeTarget.chapter, targetVerse, chapterTitle);
      })
      .catch(() => {
        if (active) setReaderLoading(false);
      });

    return () => {
      active = false;
    };
  }, [activeTarget?.scripture, activeTarget?.chapter, activeTarget?.verse, language]);

  // Scroll to target verse once loaded
  useEffect(() => {
    if (!activeTarget?.verse || readerLoading || readerVerses.length === 0) return;
    const el = verseRefs.current[activeTarget.verse];
    if (el) {
      setTimeout(() => {
        el.scrollIntoView({behavior: 'smooth', block: 'center'});
      }, 80);
    }
  }, [activeTarget?.verse, readerLoading, readerVerses]);

  const activeGitaMeta = useMemo(() => {
    if (!activeTarget || activeTarget.scripture !== 'gita') return null;
    return gitaChapters.find(c => c.number === activeTarget.chapter) ?? null;
  }, [activeTarget, gitaChapters]);

  const activeSurahMeta = useMemo(() => {
    if (!activeTarget || activeTarget.scripture !== 'quran') return null;
    return surahs.find(s => s.number === activeTarget.chapter) ?? null;
  }, [activeTarget, surahs]);

  const handleJumpToVerse = (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseInt(jumpInput.trim(), 10);
    if (!activeTarget || Number.isNaN(num) || num < 1 || num > readerVerses.length) return;
    setHighlightedVerse(num);
    const el = verseRefs.current[num];
    if (el) {
      el.scrollIntoView({behavior: 'smooth', block: 'center'});
    }
    onRecordRead(activeTarget.scripture, activeTarget.chapter, num, readerTitle);
    setJumpInput('');
  };

  const handleShareVerse = async (v: ScriptureVerseView) => {
    const res = await shareVerse(v);
    if (res === 'copied') onShowToast(t.copiedNotice);
  };

  // READER VIEW
  if (activeTarget) {
    const maxChapter = activeTarget.scripture === 'quran' ? 114 : 18;
    const hasPrev = activeTarget.chapter > 1;
    const hasNext = activeTarget.chapter < maxChapter;

    return (
      <div className="space-y-6 pb-10">
        {/* Reader Sticky Sub-Toolbar */}
        <div className="rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] p-4 sm:p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => onOpenTarget(null)}
              className="min-h-[44px] px-3 -ml-2 inline-flex items-center gap-2 text-sm font-medium text-[#5C5850] dark:text-[#A8A39A] hover:text-[#1C1B18] dark:hover:text-[#ECE8DF] cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>{t.backToIndex}</span>
            </button>

            <div className="flex flex-wrap items-center gap-2">
              {/* Language Switcher: strictly English and हिंदी */}
              <div className="inline-flex items-center p-1 rounded-xl bg-[#EFECE5] dark:bg-[#111214] border border-[#E3DDD1] dark:border-[#24252A]">
                <button
                  type="button"
                  onClick={() => onChangeLanguage('en')}
                  className={`min-h-[36px] px-3 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                    language === 'en'
                      ? 'bg-white dark:bg-[#23242A] text-[#1C1B18] dark:text-[#ECE8DF] shadow-sm'
                      : 'text-[#6B665D] dark:text-[#8E8A82]'
                  }`}
                >
                  English
                </button>
                <button
                  type="button"
                  onClick={() => onChangeLanguage('hi')}
                  className={`min-h-[36px] px-3 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                    language === 'hi'
                      ? 'bg-white dark:bg-[#23242A] text-[#1C1B18] dark:text-[#ECE8DF] shadow-sm'
                      : 'text-[#6B665D] dark:text-[#8E8A82]'
                  }`}
                >
                  हिंदी
                </button>
              </div>

              {/* Text Size Switcher */}
              <div className="inline-flex items-center p-1 rounded-xl bg-[#EFECE5] dark:bg-[#111214] border border-[#E3DDD1] dark:border-[#24252A]">
                {(['sm', 'md', 'lg', 'xl'] as TextSizeOption[]).map(sz => (
                  <button
                    key={sz}
                    type="button"
                    onClick={() => onChangeTextSize(sz)}
                    aria-label={`Text size ${sz.toUpperCase()}`}
                    className={`min-h-[36px] min-w-[36px] px-2 rounded-lg text-xs font-medium uppercase transition-colors cursor-pointer ${
                      textSize === sz
                        ? 'bg-white dark:bg-[#23242A] text-[#8F6F38] dark:text-[#C9A96E] shadow-sm'
                        : 'text-[#6B665D] dark:text-[#8E8A82]'
                    }`}
                  >
                    {sz}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-[#ECE7DC] dark:border-[#24252A] flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="space-y-1">
              <p className="text-xs text-[#8F6F38] dark:text-[#C9A96E] tabular-nums">
                {activeTarget.scripture === 'quran'
                  ? `${t.holyQuran} · ${t.surahLabel} ${activeTarget.chapter} / 114`
                  : `${t.bhagavadGita} · ${t.chapterLabel} ${activeTarget.chapter} / 18`}
                {activeSurahMeta ? ` · ${activeSurahMeta.revelationPlace} · ${activeSurahMeta.versesCount} ${t.versesCountLabel}` : ''}
                {activeGitaMeta ? ` · ${activeGitaMeta.versesCount} ${t.versesCountLabel}` : ''}
              </p>
              <h1 className="font-display text-2xl sm:text-3xl font-semibold text-[#1C1B18] dark:text-[#ECE8DF]">
                {readerTitle || `${activeTarget.scripture === 'quran' ? t.surahLabel : t.chapterLabel} ${activeTarget.chapter}`}
              </h1>
            </div>

            {/* Jump to Verse */}
            <form onSubmit={handleJumpToVerse} className="flex items-center gap-2">
              <input
                type="number"
                min={1}
                max={readerVerses.length || 300}
                value={jumpInput}
                onChange={e => setJumpInput(e.target.value)}
                placeholder={`${t.jumpToVerse} (1–${readerVerses.length || '...'})`}
                className="w-36 min-h-[44px] px-3 rounded-xl bg-[#F7F5F0] dark:bg-[#111214] border border-[#D8D1C5] dark:border-[#2A2B32] text-sm text-[#1C1B18] dark:text-[#ECE8DF] placeholder:text-[#8E8A82] focus:outline-none focus:border-[#8F6F38] dark:focus:border-[#C9A96E]"
              />
              <button
                type="submit"
                className="min-h-[44px] px-4 rounded-xl bg-[#8F6F38] dark:bg-[#C9A96E] text-white dark:text-[#111214] text-xs font-semibold cursor-pointer"
              >
                {t.goLabel}
              </button>
            </form>
          </div>

          {activeGitaMeta && (
            <p className="text-xs sm:text-sm text-[#5C5850] dark:text-[#A8A39A] leading-relaxed pt-1">
              {language === 'hi' ? activeGitaMeta.summaryHi : activeGitaMeta.summaryEn}
            </p>
          )}
        </div>

        {/* Verses List */}
        {readerLoading ? (
          <div className="py-16 text-center text-sm text-[#6B665D] dark:text-[#8E8A82]">
            {t.loadingScriptures}
          </div>
        ) : (
          <div className="rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] divide-y divide-[#ECE7DC] dark:divide-[#24252A]">
            {readerVerses.map(v => {
              const saved = isBookmarked(v.scripture, v.chapter, v.verse);
              const isHighlighted = highlightedVerse === v.verse;
              return (
                <div
                  key={`${v.scripture}:${v.chapter}:${v.verse}`}
                  ref={el => {
                    verseRefs.current[v.verse] = el;
                  }}
                  onClick={() => {
                    setHighlightedVerse(v.verse);
                    onRecordRead(v.scripture, v.chapter, v.verse, v.chapterTitle);
                  }}
                  className={`p-5 sm:p-6 transition-colors ${
                    isHighlighted
                      ? 'bg-[#8F6F38]/[0.07] dark:bg-[#C9A96E]/[0.08]'
                      : 'hover:bg-black/[0.015] dark:hover:bg-white/[0.015]'
                  }`}
                >
                  <div className="flex items-start justify-between gap-4 mb-3">
                    <span className="text-xs font-semibold tracking-wide text-[#8F6F38] dark:text-[#C9A96E] tabular-nums">
                      {v.chapter}:{v.verse}
                    </span>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={e => {
                          e.stopPropagation();
                          onToggleBookmark(v.scripture, v.chapter, v.verse);
                        }}
                        aria-label={saved ? t.bookmarked : t.bookmark}
                        className={`min-h-[40px] min-w-[40px] px-2.5 rounded-lg inline-flex items-center gap-1.5 text-xs font-medium transition-colors cursor-pointer ${
                          saved
                            ? 'text-[#8F6F38] dark:text-[#C9A96E] bg-[#8F6F38]/10 dark:bg-[#C9A96E]/10'
                            : 'text-[#6B665D] dark:text-[#8E8A82] hover:text-[#1C1B18] dark:hover:text-[#ECE8DF]'
                        }`}
                      >
                        <Bookmark className="w-4 h-4" />
                        <span className="hidden sm:inline">{saved ? t.bookmarked : t.bookmark}</span>
                      </button>

                      <button
                        type="button"
                        onClick={e => {
                          e.stopPropagation();
                          void handleShareVerse(v);
                        }}
                        aria-label={t.share}
                        className="min-h-[40px] min-w-[40px] px-2.5 rounded-lg inline-flex items-center gap-1.5 text-xs font-medium text-[#6B665D] dark:text-[#8E8A82] hover:text-[#1C1B18] dark:hover:text-[#ECE8DF] cursor-pointer"
                      >
                        <Share2 className="w-4 h-4" />
                        <span className="hidden sm:inline">{t.share}</span>
                      </button>
                    </div>
                  </div>

                  <p className={`text-[#1C1B18] dark:text-[#ECE8DF] ${TEXT_SIZE_CLASSES[textSize]}`}>
                    {v.text}
                  </p>
                </div>
              );
            })}
          </div>
        )}

        {/* Prev / Next Chapter Footer */}
        <div className="flex items-center justify-between gap-4">
          <button
            type="button"
            disabled={!hasPrev}
            onClick={() =>
              hasPrev &&
              onOpenTarget({
                scripture: activeTarget.scripture,
                chapter: activeTarget.chapter - 1,
                verse: 1,
              })
            }
            className="min-h-[44px] px-4 rounded-xl border border-[#D8D1C5] dark:border-[#2C2D33] text-sm font-medium text-[#1C1B18] dark:text-[#ECE8DF] disabled:opacity-35 inline-flex items-center gap-2 cursor-pointer disabled:cursor-not-allowed"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>{t.previous}</span>
          </button>

          <button
            type="button"
            disabled={!hasNext}
            onClick={() =>
              hasNext &&
              onOpenTarget({
                scripture: activeTarget.scripture,
                chapter: activeTarget.chapter + 1,
                verse: 1,
              })
            }
            className="min-h-[44px] px-4 rounded-xl bg-[#8F6F38] dark:bg-[#C9A96E] text-white dark:text-[#111214] text-sm font-semibold disabled:opacity-35 inline-flex items-center gap-2 cursor-pointer disabled:cursor-not-allowed"
          >
            <span>{t.next}</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  // INDEX & SEARCH VIEW
  return (
    <div className="space-y-6 pb-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#1C1B18] dark:text-[#ECE8DF]">
            {t.navScriptures}
          </h1>
          <p className="text-sm text-[#6B665D] dark:text-[#8E8A82] mt-1 tabular-nums">
            {t.holyQuran}: {t.quranMeta} · {t.bhagavadGita}: {t.gitaMeta}
          </p>
        </div>

        {/* Scripture Segmented Selector */}
        <div className="inline-flex items-center p-1 rounded-xl bg-[#EFECE5] dark:bg-[#17181C] border border-[#E3DDD1] dark:border-[#24252A] self-start">
          <button
            type="button"
            onClick={() => onChangeScripture('quran')}
            className={`min-h-[40px] px-4 rounded-lg text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              selectedScripture === 'quran'
                ? 'bg-white dark:bg-[#23242A] text-[#8F6F38] dark:text-[#C9A96E] shadow-sm'
                : 'text-[#5C5850] dark:text-[#A8A39A]'
            }`}
          >
            {t.holyQuran}
          </button>
          <button
            type="button"
            onClick={() => onChangeScripture('gita')}
            className={`min-h-[40px] px-4 rounded-lg text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              selectedScripture === 'gita'
                ? 'bg-white dark:bg-[#23242A] text-[#8F6F38] dark:text-[#C9A96E] shadow-sm'
                : 'text-[#5C5850] dark:text-[#A8A39A]'
            }`}
          >
            {t.bhagavadGita}
          </button>
        </div>
      </div>

      {/* Unified Search & Filters */}
      <div className="rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] p-4 space-y-3">
        <div className="relative flex items-center">
          <Search className="w-4 h-4 text-[#8E8A82] absolute left-3.5 pointer-events-none" />
          <input
            type="search"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="w-full min-h-[46px] pl-10 pr-10 rounded-xl bg-[#F7F5F0] dark:bg-[#111214] border border-[#D8D1C5] dark:border-[#2A2B32] text-sm text-[#1C1B18] dark:text-[#ECE8DF] placeholder:text-[#8E8A82] focus:outline-none focus:border-[#8F6F38] dark:focus:border-[#C9A96E]"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              aria-label="Clear search"
              className="absolute right-2 min-h-[36px] min-w-[36px] flex items-center justify-center text-[#8E8A82] hover:text-[#1C1B18] dark:hover:text-[#ECE8DF] cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2">
          {/* Scripture Scope Filter */}
          <div className="flex flex-wrap items-center gap-1.5">
            {(['all', 'quran', 'gita'] as const).map(scope => (
              <button
                key={scope}
                type="button"
                onClick={() => setSearchScope(scope)}
                className={`min-h-[36px] px-3 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  searchScope === scope
                    ? 'bg-[#8F6F38] dark:bg-[#C9A96E] text-white dark:text-[#111214]'
                    : 'bg-[#F7F5F0] dark:bg-[#111214] text-[#5C5850] dark:text-[#A8A39A]'
                }`}
              >
                {scope === 'all' ? t.allScriptures : scope === 'quran' ? t.holyQuran : t.bhagavadGita}
              </button>
            ))}
          </div>

          {/* Language Filter (strictly EN / HI) */}
          <div className="inline-flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => onChangeLanguage('en')}
              className={`min-h-[36px] px-3 rounded-lg text-xs font-medium cursor-pointer ${
                language === 'en'
                  ? 'border border-[#8F6F38] dark:border-[#C9A96E] text-[#8F6F38] dark:text-[#C9A96E]'
                  : 'text-[#6B665D] dark:text-[#8E8A82]'
              }`}
            >
              English
            </button>
            <button
              type="button"
              onClick={() => onChangeLanguage('hi')}
              className={`min-h-[36px] px-3 rounded-lg text-xs font-medium cursor-pointer ${
                language === 'hi'
                  ? 'border border-[#8F6F38] dark:border-[#C9A96E] text-[#8F6F38] dark:text-[#C9A96E]'
                  : 'text-[#6B665D] dark:text-[#8E8A82]'
              }`}
            >
              हिंदी
            </button>
          </div>
        </div>
      </div>

      {/* Search Results OR Surah/Chapter Directory */}
      {searchQuery.trim() ? (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs text-[#6B665D] dark:text-[#8E8A82]">
            <span>{t.searchResultsLabel}</span>
            <span className="tabular-nums">{searching ? '...' : `${searchResults.length}`}</span>
          </div>

          {!searching && searchResults.length === 0 ? (
            <div className="rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] p-8 text-center text-sm text-[#6B665D] dark:text-[#8E8A82]">
              {t.noSearchResults}
            </div>
          ) : (
            <div className="rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] divide-y divide-[#ECE7DC] dark:divide-[#24252A]">
              {searchResults.map(res => (
                <button
                  key={`${res.scripture}:${res.chapter}:${res.verse}`}
                  type="button"
                  onClick={() =>
                    onOpenTarget({
                      scripture: res.scripture,
                      chapter: res.chapter,
                      verse: res.verse,
                    })
                  }
                  className="w-full p-5 text-left hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition-colors space-y-1.5 cursor-pointer"
                >
                  <p className="text-xs font-medium text-[#8F6F38] dark:text-[#C9A96E] tabular-nums">
                    {res.scripture === 'quran' ? t.holyQuran : t.bhagavadGita} · {res.chapter}:{res.verse} ·{' '}
                    {res.chapterTitle}
                  </p>
                  <p className="text-sm text-[#1C1B18] dark:text-[#ECE8DF] leading-relaxed">
                    {res.text}
                  </p>
                </button>
              ))}
            </div>
          )}
        </div>
      ) : indexLoading ? (
        <div className="py-16 text-center text-sm text-[#6B665D] dark:text-[#8E8A82]">
          {t.loadingScriptures}
        </div>
      ) : selectedScripture === 'quran' ? (
        /* All 114 Surahs */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {surahs.map(surah => (
            <button
              key={surah.number}
              type="button"
              onClick={() => onOpenTarget({scripture: 'quran', chapter: surah.number, verse: 1})}
              className="min-h-[76px] p-4 rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] hover:border-[#8F6F38] dark:hover:border-[#C9A96E]/60 transition-colors flex items-center justify-between gap-4 text-left cursor-pointer"
            >
              <div className="flex items-center gap-3.5 min-w-0">
                <span className="w-9 h-9 rounded-xl bg-[#F7F5F0] dark:bg-[#111214] border border-[#E3DDD1] dark:border-[#24252A] flex items-center justify-center text-xs font-semibold text-[#8F6F38] dark:text-[#C9A96E] tabular-nums shrink-0">
                  {surah.number}
                </span>
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-[#1C1B18] dark:text-[#ECE8DF] truncate">
                    {surah.name}
                  </p>
                  <p className="text-xs text-[#6B665D] dark:text-[#8E8A82] truncate">
                    {surah.englishName} · {surah.revelationPlace}
                  </p>
                </div>
              </div>
              <span className="text-xs text-[#6B665D] dark:text-[#8E8A82] tabular-nums shrink-0">
                {surah.versesCount}
              </span>
            </button>
          ))}
        </div>
      ) : (
        /* All 18 Bhagavad Gita Chapters */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {gitaChapters.map(chap => (
            <button
              key={chap.number}
              type="button"
              onClick={() => onOpenTarget({scripture: 'gita', chapter: chap.number, verse: 1})}
              className="p-5 rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] hover:border-[#8F6F38] dark:hover:border-[#C9A96E]/60 transition-colors text-left space-y-2.5 cursor-pointer"
            >
              <div className="flex items-baseline justify-between gap-3">
                <span className="text-xs font-semibold text-[#8F6F38] dark:text-[#C9A96E] tabular-nums">
                  {t.chapterLabel} {chap.number}
                </span>
                <span className="text-xs text-[#6B665D] dark:text-[#8E8A82] tabular-nums">
                  {chap.versesCount} {t.versesCountLabel}
                </span>
              </div>
              <h3 className="font-display text-xl font-semibold text-[#1C1B18] dark:text-[#ECE8DF]">
                {chap.nameTransliterated} — {chap.nameMeaningEn}
              </h3>
              <p className="text-xs text-[#5C5850] dark:text-[#A8A39A] leading-relaxed line-clamp-3">
                {language === 'hi' ? chap.summaryHi : chap.summaryEn}
              </p>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
