import React, {useEffect, useState} from 'react';
import {
  ArrowRight,
  Bookmark,
  BookOpen,
  ChevronLeft,
  ChevronRight,
  Clock,
  Compass,
  Share2,
} from 'lucide-react';
import {DAILY_WISDOM_SEEDS, getDailyWisdomIndex} from '../data/dailyWisdom';
import {GUIDANCE_CATEGORIES} from '../data/guidance';
import {UI_STRINGS} from '../lib/i18n';
import {getSingleVerse} from '../lib/scriptureStore';
import {shareVerse} from '../lib/share';
import type {
  BookmarkItem,
  ContinueReadingPosition,
  GuidanceCategoryId,
  LanguageCode,
  ReadingHistoryItem,
  ReaderTarget,
  ScriptureId,
  ScriptureVerseView,
  TabId,
} from '../types/scripture';

interface HomeScreenProps {
  language: LanguageCode;
  displayName: string;
  continueReading: ContinueReadingPosition | null;
  bookmarks: BookmarkItem[];
  history: ReadingHistoryItem[];
  isBookmarked: (scripture: ScriptureId, chapter: number, verse: number) => boolean;
  onToggleBookmark: (scripture: ScriptureId, chapter: number, verse: number) => void;
  onOpenReader: (target: ReaderTarget) => void;
  onOpenScriptureIndex: (scripture: ScriptureId) => void;
  onOpenGuidance: (categoryId?: GuidanceCategoryId) => void;
  onNavigateTab: (tab: TabId) => void;
  onShowToast: (msg: string) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  language,
  displayName,
  continueReading,
  bookmarks,
  history,
  isBookmarked,
  onToggleBookmark,
  onOpenReader,
  onOpenScriptureIndex,
  onOpenGuidance,
  onNavigateTab,
  onShowToast,
}) => {
  const t = UI_STRINGS[language];
  const [wisdomOffset, setWisdomOffset] = useState(0);
  const [wisdomVerse, setWisdomVerse] = useState<ScriptureVerseView | null>(null);
  const [recentBookmarks, setRecentBookmarks] = useState<ScriptureVerseView[]>([]);

  const wisdomIdx = getDailyWisdomIndex(wisdomOffset);
  const wisdomSeed = DAILY_WISDOM_SEEDS[wisdomIdx];

  useEffect(() => {
    let active = true;
    getSingleVerse(wisdomSeed.scripture, wisdomSeed.chapter, wisdomSeed.verse, language)
      .then(v => {
        if (active) setWisdomVerse(v);
      })
      .catch(() => {
        if (active) setWisdomVerse(null);
      });
    return () => {
      active = false;
    };
  }, [wisdomSeed.scripture, wisdomSeed.chapter, wisdomSeed.verse, language]);

  useEffect(() => {
    let active = true;
    const topBookmarks = bookmarks.slice(0, 3);
    Promise.all(
      topBookmarks.map(b => getSingleVerse(b.scripture, b.chapter, b.verse, language))
    )
      .then(items => {
        if (active) {
          setRecentBookmarks(items.filter((x): x is ScriptureVerseView => x !== null));
        }
      })
      .catch(() => {
        if (active) setRecentBookmarks([]);
      });
    return () => {
      active = false;
    };
  }, [bookmarks, language]);

  const handleShareWisdom = async () => {
    if (!wisdomVerse) return;
    const result = await shareVerse(wisdomVerse);
    if (result === 'copied') onShowToast(t.copiedNotice);
  };

  const featuredGuidance = GUIDANCE_CATEGORIES.slice(0, 6);
  const recentHistory = history.slice(0, 4);
  const wisdomSaved = isBookmarked(wisdomSeed.scripture, wisdomSeed.chapter, wisdomSeed.verse);

  return (
    <div className="space-y-10 pb-8">
      {/* Calm Architectural Hero Sanctuary */}
      <section className="relative overflow-hidden rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-[#16171B]">
        <div className="absolute inset-0">
          <img
            src="/src/assets/images/relief_hero_sanctuary_1795629541261.jpg"
            alt="Quiet stone sanctuary illuminated by warm golden light"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-55"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#111214] via-[#111214]/75 to-[#111214]/45" />
        </div>

        <div className="relative z-10 p-6 sm:p-8 lg:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-end">
          <div className="lg:col-span-7 space-y-4">
            <p className="text-xs font-medium tracking-[0.18em] text-[#C9A96E]">
              RELIEF · {t.appTagline}
            </p>
            <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-semibold text-[#F2EEE6] leading-[1.15] [text-wrap:balance]">
              {displayName && displayName !== 'Seeker'
                ? language === 'hi'
                  ? `नमस्ते, ${displayName} — ${t.welcomeTitle}`
                  : `Peace, ${displayName}. ${t.welcomeTitle}`
                : t.welcomeTitle}
            </h1>
            <p className="text-sm sm:text-base text-[#C8C2B6] max-w-2xl leading-relaxed">
              {t.welcomeBody}
            </p>
          </div>

          {/* Continue Reading Panel inside Hero */}
          <div className="lg:col-span-5">
            <div className="rounded-xl bg-[#18191D]/90 backdrop-blur-md border border-[#2D2E35] p-5 space-y-3">
              <div className="flex items-center justify-between gap-2 text-xs text-[#C9A96E]">
                <span className="font-medium">{t.continueReading}</span>
                {continueReading && (
                  <span className="tabular-nums text-[#A8A39A]">
                    {continueReading.scripture === 'quran' ? t.holyQuran : t.bhagavadGita} ·{' '}
                    {continueReading.chapter}:{continueReading.verse}
                  </span>
                )}
              </div>

              {continueReading ? (
                <>
                  <p className="font-display text-xl font-medium text-[#ECE8DF] truncate">
                    {continueReading.chapterTitle}
                  </p>
                  <button
                    type="button"
                    onClick={() =>
                      onOpenReader({
                        scripture: continueReading.scripture,
                        chapter: continueReading.chapter,
                        verse: continueReading.verse,
                      })
                    }
                    className="w-full min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl bg-[#C9A96E] text-[#111214] text-sm font-semibold hover:bg-[#D5B77E] transition-colors cursor-pointer"
                  >
                    <span>
                      {t.openReader} ({continueReading.chapter}:{continueReading.verse})
                    </span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </>
              ) : (
                <>
                  <p className="font-display text-xl font-medium text-[#ECE8DF]">
                    {language === 'hi' ? 'सूरह अल-फ़ातिहा · 1:1' : 'Surah Al-Faatiha · 1:1'}
                  </p>
                  <button
                    type="button"
                    onClick={() => onOpenReader({scripture: 'quran', chapter: 1, verse: 1})}
                    className="w-full min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl bg-[#C9A96E] text-[#111214] text-sm font-semibold hover:bg-[#D5B77E] transition-colors cursor-pointer"
                  >
                    <span>{t.startReading}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Two Primary Scripture Libraries: Holy Quran & Bhagavad Gita */}
      <section aria-labelledby="scripture-collections-heading" className="space-y-4">
        <div className="flex items-baseline justify-between gap-4">
          <h2
            id="scripture-collections-heading"
            className="font-display text-2xl sm:text-3xl font-semibold text-[#1C1B18] dark:text-[#ECE8DF]"
          >
            {t.navScriptures}
          </h2>
          <span className="text-xs text-[#6B665D] dark:text-[#8E8A82]">
            {language === 'hi' ? 'अंग्रेज़ी एवं हिंदी अनुवाद' : 'English & Hindi Translations'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Holy Quran Card */}
          <button
            type="button"
            onClick={() => onOpenScriptureIndex('quran')}
            className="group text-left rounded-2xl overflow-hidden border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] hover:border-[#8F6F38] dark:hover:border-[#C9A96E]/60 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C9A96E]"
          >
            <div className="relative h-40 sm:h-44 overflow-hidden bg-[#1D1E22]">
              <img
                src="/src/assets/images/quran_collection_cover_1795629542022.jpg"
                alt="Minimalist obsidian stone and warm gold rim light representing Holy Quran library"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/25 to-transparent" />
              <div className="absolute bottom-4 left-5 right-5 flex items-end justify-between gap-4">
                <div>
                  <p className="text-xs text-[#D6B87D] tabular-nums">{t.quranMeta}</p>
                  <h3 className="font-display text-2xl font-semibold text-[#F4F0E8] mt-0.5">
                    {t.holyQuran}
                  </h3>
                </div>
                <BookOpen className="w-5 h-5 text-[#D6B87D] shrink-0" />
              </div>
            </div>
            <div className="p-5 flex items-center justify-between gap-4">
              <p className="text-sm text-[#5C5850] dark:text-[#A8A39A] leading-relaxed">
                {language === 'hi'
                  ? 'सूरह-वार अध्ययन, आयत संख्या खोज और स्पष्ट अनुवाद।'
                  : 'Surah-by-Surah navigation, verse numbering, and clear translations.'}
              </p>
              <ArrowRight className="w-4 h-4 text-[#8F6F38] dark:text-[#C9A96E] shrink-0 group-hover:translate-x-0.5 transition-transform" />
            </div>
          </button>

          {/* Bhagavad Gita Card */}
          <button
            type="button"
            onClick={() => onOpenScriptureIndex('gita')}
            className="group text-left rounded-2xl overflow-hidden border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] hover:border-[#8F6F38] dark:hover:border-[#C9A96E]/60 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C9A96E]"
          >
            <div className="relative h-40 sm:h-44 overflow-hidden bg-[#1D1E22]">
              <img
                src="/src/assets/images/gita_collection_cover_1795629542250.jpg"
                alt="Calm dark water pool reflecting warm golden dawn light representing Bhagavad Gita library"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/25 to-transparent" />
              <div className="absolute bottom-4 left-5 right-5 flex items-end justify-between gap-4">
                <div>
                  <p className="text-xs text-[#D6B87D] tabular-nums">{t.gitaMeta}</p>
                  <h3 className="font-display text-2xl font-semibold text-[#F4F0E8] mt-0.5">
                    {t.bhagavadGita}
                  </h3>
                </div>
                <BookOpen className="w-5 h-5 text-[#D6B87D] shrink-0" />
              </div>
            </div>
            <div className="p-5 flex items-center justify-between gap-4">
              <p className="text-sm text-[#5C5850] dark:text-[#A8A39A] leading-relaxed">
                {language === 'hi'
                  ? 'अध्याय-वार श्लोक संग्रह, सार और गहन आध्यात्मिक पाठ।'
                  : 'Chapter-wise verses, chapter summaries, and serene study.'}
              </p>
              <ArrowRight className="w-4 h-4 text-[#8F6F38] dark:text-[#C9A96E] shrink-0 group-hover:translate-x-0.5 transition-transform" />
            </div>
          </button>
        </div>
      </section>

      {/* Daily Wisdom */}
      <section aria-labelledby="daily-wisdom-heading" className="space-y-4">
        <div className="flex items-center justify-between gap-4">
          <h2
            id="daily-wisdom-heading"
            className="font-display text-2xl sm:text-3xl font-semibold text-[#1C1B18] dark:text-[#ECE8DF]"
          >
            {t.dailyWisdom}
          </h2>
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setWisdomOffset(o => o - 1)}
              aria-label={t.prevWisdom}
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl border border-[#E3DDD1] dark:border-[#24252A] text-[#5C5850] dark:text-[#A8A39A] hover:text-[#1C1B18] dark:hover:text-[#ECE8DF] cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setWisdomOffset(o => o + 1)}
              aria-label={t.nextWisdom}
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl border border-[#E3DDD1] dark:border-[#24252A] text-[#5C5850] dark:text-[#A8A39A] hover:text-[#1C1B18] dark:hover:text-[#ECE8DF] cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] p-6 sm:p-8 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#6B665D] dark:text-[#8E8A82]">
            <span>
              {t.scriptureQuotation} ·{' '}
              <strong className="font-medium text-[#8F6F38] dark:text-[#C9A96E]">
                {wisdomSeed.scripture === 'quran' ? t.holyQuran : t.bhagavadGita}
              </strong>{' '}
              · <span className="tabular-nums">{wisdomSeed.chapter}:{wisdomSeed.verse}</span>
            </span>
            {wisdomVerse && <span>{wisdomVerse.chapterTitle}</span>}
          </div>

          <blockquote className="font-display text-xl sm:text-2xl leading-relaxed text-[#1C1B18] dark:text-[#ECE8DF]">
            {wisdomVerse ? `“${wisdomVerse.text}”` : t.loadingScriptures}
          </blockquote>

          <div className="pt-4 border-t border-[#ECE7DC] dark:border-[#24252A] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <p className="text-xs font-medium text-[#8F6F38] dark:text-[#C9A96E]">
                {t.explanatoryReflection}
              </p>
              <p className="text-sm text-[#5C5850] dark:text-[#A8A39A] leading-relaxed">
                {language === 'hi' ? wisdomSeed.reflectionHi : wisdomSeed.reflectionEn}
              </p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() =>
                  onToggleBookmark(wisdomSeed.scripture, wisdomSeed.chapter, wisdomSeed.verse)
                }
                className={`min-h-[44px] px-3.5 rounded-xl border text-xs font-medium inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                  wisdomSaved
                    ? 'border-[#8F6F38] dark:border-[#C9A96E] text-[#8F6F38] dark:text-[#C9A96E]'
                    : 'border-[#E3DDD1] dark:border-[#2A2B32] text-[#5C5850] dark:text-[#A8A39A] hover:text-[#1C1B18] dark:hover:text-[#ECE8DF]'
                }`}
              >
                <Bookmark className="w-4 h-4" />
                <span>{wisdomSaved ? t.bookmarked : t.bookmark}</span>
              </button>
              <button
                type="button"
                onClick={() => void handleShareWisdom()}
                className="min-h-[44px] px-3.5 rounded-xl border border-[#E3DDD1] dark:border-[#2A2B32] text-xs font-medium text-[#5C5850] dark:text-[#A8A39A] hover:text-[#1C1B18] dark:hover:text-[#ECE8DF] inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Share2 className="w-4 h-4" />
                <span>{t.share}</span>
              </button>
              <button
                type="button"
                onClick={() =>
                  onOpenReader({
                    scripture: wisdomSeed.scripture,
                    chapter: wisdomSeed.chapter,
                    verse: wisdomSeed.verse,
                  })
                }
                className="min-h-[44px] px-4 rounded-xl bg-[#8F6F38] dark:bg-[#C9A96E] text-white dark:text-[#111214] text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
              >
                <span>{t.openReader}</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Explore Life Guidance */}
      <section aria-labelledby="explore-guidance-heading" className="space-y-4">
        <div className="flex items-center justify-between gap-4">
          <h2
            id="explore-guidance-heading"
            className="font-display text-2xl sm:text-3xl font-semibold text-[#1C1B18] dark:text-[#ECE8DF]"
          >
            {t.exploreGuidance}
          </h2>
          <button
            type="button"
            onClick={() => onOpenGuidance()}
            className="min-h-[44px] inline-flex items-center gap-1.5 text-xs font-medium text-[#8F6F38] dark:text-[#C9A96E] hover:underline cursor-pointer whitespace-nowrap"
          >
            <span>{t.viewAllCategories}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {featuredGuidance.map(cat => (
            <button
              key={cat.id}
              type="button"
              onClick={() => onOpenGuidance(cat.id)}
              className="text-left p-5 rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] hover:border-[#8F6F38] dark:hover:border-[#C9A96E]/60 transition-colors cursor-pointer space-y-2"
            >
              <div className="flex items-center justify-between gap-3">
                <h3 className="text-base font-semibold text-[#1C1B18] dark:text-[#ECE8DF]">
                  {language === 'hi' ? cat.titleHi : cat.titleEn}
                </h3>
                <Compass className="w-4 h-4 text-[#8F6F38] dark:text-[#C9A96E] shrink-0" />
              </div>
              <p className="text-xs text-[#6B665D] dark:text-[#8E8A82] leading-relaxed line-clamp-2">
                {language === 'hi' ? cat.subtitleHi : cat.subtitleEn}
              </p>
            </button>
          ))}
        </div>
      </section>

      {/* Recently Read & Bookmarked Verses Split */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recently Read */}
        <div className="rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] p-6 space-y-4">
          <div className="flex items-center justify-between gap-4">
            <h2 className="font-display text-2xl font-semibold text-[#1C1B18] dark:text-[#ECE8DF]">
              {t.recentlyRead}
            </h2>
            <button
              type="button"
              onClick={() => onNavigateTab('bookmarks')}
              className="text-xs font-medium text-[#8F6F38] dark:text-[#C9A96E] hover:underline cursor-pointer"
            >
              {t.readingHistoryTab}
            </button>
          </div>

          {recentHistory.length === 0 ? (
            <p className="text-sm text-[#6B665D] dark:text-[#8E8A82] py-4">
              {t.noRecentReading}
            </p>
          ) : (
            <div className="divide-y divide-[#ECE7DC] dark:divide-[#24252A]">
              {recentHistory.map(item => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() =>
                    onOpenReader({
                      scripture: item.scripture,
                      chapter: item.chapter,
                      verse: item.verse,
                    })
                  }
                  className="w-full min-h-[56px] py-3 flex items-center justify-between gap-3 text-left hover:opacity-80 transition-opacity cursor-pointer"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-[#1C1B18] dark:text-[#ECE8DF] truncate">
                      {item.chapterTitle}
                    </p>
                    <p className="text-xs text-[#6B665D] dark:text-[#8E8A82] tabular-nums">
                      {item.scripture === 'quran' ? t.holyQuran : t.bhagavadGita} · {item.chapter}:{item.verse}
                    </p>
                  </div>
                  <Clock className="w-4 h-4 text-[#8E8A82] shrink-0" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Bookmarked Verses */}
        <div className="rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] p-6 space-y-4">
          <div className="flex items-center justify-between gap-4">
            <h2 className="font-display text-2xl font-semibold text-[#1C1B18] dark:text-[#ECE8DF]">
              {t.bookmarkedVerses}
            </h2>
            <button
              type="button"
              onClick={() => onNavigateTab('bookmarks')}
              className="text-xs font-medium text-[#8F6F38] dark:text-[#C9A96E] hover:underline cursor-pointer"
            >
              {t.savedVersesTab} ({bookmarks.length})
            </button>
          </div>

          {recentBookmarks.length === 0 ? (
            <p className="text-sm text-[#6B665D] dark:text-[#8E8A82] py-4">
              {t.noBookmarksYet}
            </p>
          ) : (
            <div className="divide-y divide-[#ECE7DC] dark:divide-[#24252A]">
              {recentBookmarks.map(bm => (
                <button
                  key={`${bm.scripture}:${bm.chapter}:${bm.verse}`}
                  type="button"
                  onClick={() =>
                    onOpenReader({
                      scripture: bm.scripture,
                      chapter: bm.chapter,
                      verse: bm.verse,
                    })
                  }
                  className="w-full py-3 text-left space-y-1 hover:opacity-80 transition-opacity cursor-pointer"
                >
                  <p className="text-xs text-[#8F6F38] dark:text-[#C9A96E] tabular-nums">
                    {bm.scripture === 'quran' ? t.holyQuran : t.bhagavadGita} · {bm.chapter}:{bm.verse} ·{' '}
                    {bm.chapterTitle}
                  </p>
                  <p className="text-sm text-[#1C1B18] dark:text-[#ECE8DF] line-clamp-2 leading-relaxed">
                    {bm.text}
                  </p>
                </button>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
};
