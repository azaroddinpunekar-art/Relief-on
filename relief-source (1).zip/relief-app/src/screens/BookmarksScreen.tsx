import React, {useEffect, useMemo, useState} from 'react';
import {ArrowRight, Clock, Search, Share2, Trash2} from 'lucide-react';
import {UI_STRINGS} from '../lib/i18n';
import {getSingleVerse} from '../lib/scriptureStore';
import {shareVerse} from '../lib/share';
import type {
  BookmarkItem,
  LanguageCode,
  ReadingHistoryItem,
  ReaderTarget,
  ScriptureId,
  ScriptureVerseView,
} from '../types/scripture';

interface BookmarksScreenProps {
  language: LanguageCode;
  bookmarks: BookmarkItem[];
  history: ReadingHistoryItem[];
  onRemoveBookmark: (id: string) => void;
  onUpdateBookmarkNote: (id: string, note: string) => void;
  onClearHistory: () => void;
  onOpenReader: (target: ReaderTarget) => void;
  onShowToast: (msg: string) => void;
}

interface HydratedBookmark extends BookmarkItem {
  verseData: ScriptureVerseView | null;
}

export const BookmarksScreen: React.FC<BookmarksScreenProps> = ({
  language,
  bookmarks,
  history,
  onRemoveBookmark,
  onUpdateBookmarkNote,
  onClearHistory,
  onOpenReader,
  onShowToast,
}) => {
  const t = UI_STRINGS[language];
  const [subTab, setSubTab] = useState<'bookmarks' | 'history'>('bookmarks');
  const [filterScripture, setFilterScripture] = useState<'all' | ScriptureId>('all');
  const [query, setQuery] = useState('');
  const [hydrated, setHydrated] = useState<HydratedBookmark[]>([]);
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [noteDraft, setNoteDraft] = useState('');

  useEffect(() => {
    let active = true;
    Promise.all(
      bookmarks.map(async b => ({
        ...b,
        verseData: await getSingleVerse(b.scripture, b.chapter, b.verse, language),
      }))
    )
      .then(res => {
        if (active) setHydrated(res);
      })
      .catch(() => {
        if (active) setHydrated([]);
      });
    return () => {
      active = false;
    };
  }, [bookmarks, language]);

  const filteredBookmarks = useMemo(() => {
    const q = query.trim().toLowerCase();
    return hydrated.filter(item => {
      if (filterScripture !== 'all' && item.scripture !== filterScripture) return false;
      if (!q) return true;
      const text = item.verseData?.text.toLowerCase() || '';
      const title = item.verseData?.chapterTitle.toLowerCase() || '';
      const ref = `${item.chapter}:${item.verse}`;
      const note = (item.note || '').toLowerCase();
      return text.includes(q) || title.includes(q) || ref.includes(q) || note.includes(q);
    });
  }, [hydrated, filterScripture, query]);

  const filteredHistory = useMemo(() => {
    if (filterScripture === 'all') return history;
    return history.filter(h => h.scripture === filterScripture);
  }, [history, filterScripture]);

  const handleShare = async (item: HydratedBookmark) => {
    if (!item.verseData) return;
    const res = await shareVerse(item.verseData);
    if (res === 'copied') onShowToast(t.copiedNotice);
  };

  return (
    <div className="space-y-6 pb-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#1C1B18] dark:text-[#ECE8DF]">
            {t.navBookmarks}
          </h1>
          <p className="text-sm text-[#6B665D] dark:text-[#8E8A82] mt-1 tabular-nums">
            {bookmarks.length} {t.savedVersesTab} · {history.length} {t.readingHistoryTab}
          </p>
        </div>

        {/* Sub-Tab Selector */}
        <div className="inline-flex items-center p-1 rounded-xl bg-[#EFECE5] dark:bg-[#17181C] border border-[#E3DDD1] dark:border-[#24252A] self-start">
          <button
            type="button"
            onClick={() => setSubTab('bookmarks')}
            className={`min-h-[40px] px-4 rounded-lg text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              subTab === 'bookmarks'
                ? 'bg-white dark:bg-[#23242A] text-[#8F6F38] dark:text-[#C9A96E] shadow-sm'
                : 'text-[#5C5850] dark:text-[#A8A39A]'
            }`}
          >
            {t.savedVersesTab}
          </button>
          <button
            type="button"
            onClick={() => setSubTab('history')}
            className={`min-h-[40px] px-4 rounded-lg text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              subTab === 'history'
                ? 'bg-white dark:bg-[#23242A] text-[#8F6F38] dark:text-[#C9A96E] shadow-sm'
                : 'text-[#5C5850] dark:text-[#A8A39A]'
            }`}
          >
            {t.readingHistoryTab}
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-1.5">
          {(['all', 'quran', 'gita'] as const).map(scope => (
            <button
              key={scope}
              type="button"
              onClick={() => setFilterScripture(scope)}
              className={`min-h-[40px] px-3.5 rounded-xl text-xs font-medium transition-colors cursor-pointer ${
                filterScripture === scope
                  ? 'bg-[#8F6F38] dark:bg-[#C9A96E] text-white dark:text-[#111214]'
                  : 'bg-white dark:bg-[#17181C] border border-[#E3DDD1] dark:border-[#24252A] text-[#5C5850] dark:text-[#A8A39A]'
              }`}
            >
              {scope === 'all' ? t.allScriptures : scope === 'quran' ? t.holyQuran : t.bhagavadGita}
            </button>
          ))}
        </div>

        {subTab === 'bookmarks' ? (
          <div className="relative flex items-center w-full sm:w-72">
            <Search className="w-4 h-4 text-[#8E8A82] absolute left-3 pointer-events-none" />
            <input
              type="search"
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full min-h-[42px] pl-9 pr-3 rounded-xl bg-white dark:bg-[#17181C] border border-[#E3DDD1] dark:border-[#24252A] text-sm text-[#1C1B18] dark:text-[#ECE8DF] placeholder:text-[#8E8A82] focus:outline-none focus:border-[#8F6F38] dark:focus:border-[#C9A96E]"
            />
          </div>
        ) : (
          history.length > 0 && (
            <button
              type="button"
              onClick={onClearHistory}
              className="min-h-[40px] px-3.5 rounded-xl border border-[#E3DDD1] dark:border-[#24252A] text-xs font-medium text-[#5C5850] dark:text-[#A8A39A] hover:text-[#1C1B18] dark:hover:text-[#ECE8DF] inline-flex items-center gap-1.5 self-start cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{t.clearHistory}</span>
            </button>
          )
        )}
      </div>

      {/* Content */}
      {subTab === 'bookmarks' ? (
        filteredBookmarks.length === 0 ? (
          <div className="rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] p-8 text-center text-sm text-[#6B665D] dark:text-[#8E8A82]">
            {t.noBookmarksYet}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredBookmarks.map(item => {
              const isEditing = editingNoteId === item.id;
              return (
                <article
                  key={item.id}
                  className="rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] p-5 space-y-4 flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-2 text-xs text-[#6B665D] dark:text-[#8E8A82]">
                      <span className="font-semibold text-[#8F6F38] dark:text-[#C9A96E] tabular-nums">
                        {item.scripture === 'quran' ? t.holyQuran : t.bhagavadGita} · {item.chapter}:
                        {item.verse}
                      </span>
                      {item.verseData && (
                        <span className="truncate">{item.verseData.chapterTitle}</span>
                      )}
                    </div>

                    <p className="text-base leading-relaxed text-[#1C1B18] dark:text-[#ECE8DF]">
                      {item.verseData ? item.verseData.text : t.loadingScriptures}
                    </p>

                    {isEditing ? (
                      <div className="space-y-2 pt-2">
                        <textarea
                          rows={2}
                          value={noteDraft}
                          onChange={e => setNoteDraft(e.target.value)}
                          placeholder={t.addNotePlaceholder}
                          className="w-full p-3 rounded-xl bg-[#F7F5F0] dark:bg-[#111214] border border-[#D8D1C5] dark:border-[#2A2B32] text-sm text-[#1C1B18] dark:text-[#ECE8DF] focus:outline-none focus:border-[#8F6F38] dark:focus:border-[#C9A96E]"
                        />
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              onUpdateBookmarkNote(item.id, noteDraft.trim());
                              setEditingNoteId(null);
                            }}
                            className="min-h-[38px] px-3.5 rounded-lg bg-[#8F6F38] dark:bg-[#C9A96E] text-white dark:text-[#111214] text-xs font-semibold cursor-pointer"
                          >
                            {t.saveNote}
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingNoteId(null)}
                            className="min-h-[38px] px-3 rounded-lg text-xs text-[#6B665D] dark:text-[#8E8A82] cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setEditingNoteId(item.id);
                          setNoteDraft(item.note || '');
                        }}
                        className="block w-full text-left text-xs text-[#6B665D] dark:text-[#8E8A82] hover:text-[#1C1B18] dark:hover:text-[#ECE8DF] pt-2 border-t border-[#ECE7DC] dark:border-[#24252A] cursor-pointer"
                      >
                        {item.note ? item.note : t.addNotePlaceholder}
                      </button>
                    )}
                  </div>

                  <div className="pt-2 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => void handleShare(item)}
                        aria-label={t.share}
                        className="min-h-[40px] min-w-[40px] px-2.5 rounded-lg text-xs text-[#6B665D] dark:text-[#8E8A82] hover:text-[#1C1B18] dark:hover:text-[#ECE8DF] inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                        <span>{t.share}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => onRemoveBookmark(item.id)}
                        aria-label="Remove bookmark"
                        className="min-h-[40px] min-w-[40px] px-2.5 rounded-lg text-xs text-[#6B665D] dark:text-[#8E8A82] hover:text-red-500 inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() =>
                        onOpenReader({
                          scripture: item.scripture,
                          chapter: item.chapter,
                          verse: item.verse,
                        })
                      }
                      className="min-h-[40px] px-3 rounded-lg text-xs font-semibold text-[#8F6F38] dark:text-[#C9A96E] hover:underline inline-flex items-center gap-1 cursor-pointer"
                    >
                      <span>{t.openReader}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        )
      ) : filteredHistory.length === 0 ? (
        <div className="rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] p-8 text-center text-sm text-[#6B665D] dark:text-[#8E8A82]">
          {t.noRecentReading}
        </div>
      ) : (
        <div className="rounded-2xl border border-[#E3DDD1] dark:border-[#24252A] bg-white dark:bg-[#17181C] divide-y divide-[#ECE7DC] dark:divide-[#24252A]">
          {filteredHistory.map(item => (
            <button
              key={item.id}
              type="button"
              onClick={() =>
                onOpenReader({
                  scripture: item.scripture,
                  chapter: item.chapter,
                  verse: item.verse,
                })
              }
              className="w-full min-h-[60px] p-4 sm:px-6 flex items-center justify-between gap-4 text-left hover:bg-black/[0.02] dark:hover:bg-white/[0.02] cursor-pointer"
            >
              <div className="min-w-0 space-y-0.5">
                <p className="text-sm font-medium text-[#1C1B18] dark:text-[#ECE8DF] truncate">
                  {item.chapterTitle}
                </p>
                <p className="text-xs text-[#6B665D] dark:text-[#8E8A82] tabular-nums">
                  {item.scripture === 'quran' ? t.holyQuran : t.bhagavadGita} · {item.chapter}:
                  {item.verse} · {new Date(item.timestamp).toLocaleDateString()}
                </p>
              </div>
              <Clock className="w-4 h-4 text-[#8E8A82] shrink-0" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
