export type ScriptureId = 'quran' | 'gita';

export type LanguageCode = 'en' | 'hi';

export type ThemeMode = 'dark' | 'light';

export type TextSizeOption = 'sm' | 'md' | 'lg' | 'xl';

export type TabId = 'home' | 'scriptures' | 'guidance' | 'bookmarks' | 'profile';

export interface QuranSurah {
  number: number;
  name: string;
  englishName: string;
  revelationPlace: string;
  versesCount: number;
}

export interface QuranVerseRecord {
  s: number;
  v: number;
  t: string;
}

export interface GitaChapter {
  number: number;
  nameTransliterated: string;
  nameMeaningEn: string;
  summaryEn: string;
  summaryHi: string;
  versesCount: number;
}

export interface GitaVerseRecord {
  c: number;
  v: number;
  t: string;
}

export interface ScriptureVerseView {
  scripture: ScriptureId;
  chapter: number;
  verse: number;
  chapterTitle: string;
  text: string;
  language: LanguageCode;
}

export interface SearchResultItem {
  scripture: ScriptureId;
  chapter: number;
  verse: number;
  chapterTitle: string;
  text: string;
  language: LanguageCode;
  matchType: 'reference' | 'chapter' | 'keyword';
}

export interface BookmarkItem {
  id: string; // e.g., "quran:2:286" or "gita:2:47"
  scripture: ScriptureId;
  chapter: number;
  verse: number;
  note?: string;
  createdAt: number;
}

export interface ReadingHistoryItem {
  id: string;
  scripture: ScriptureId;
  chapter: number;
  verse: number;
  chapterTitle: string;
  timestamp: number;
}

export interface ContinueReadingPosition {
  scripture: ScriptureId;
  chapter: number;
  verse: number;
  chapterTitle: string;
  updatedAt: number;
}

export interface UserPreferences {
  language: LanguageCode;
  theme: ThemeMode;
  textSize: TextSizeOption;
  dailyWisdomNotification: boolean;
  notificationTime: string; // "07:30"
  displayName: string;
}

export interface GuidanceReference {
  chapter: number;
  verse: number;
  reflectionEn: string;
  reflectionHi: string;
}

export type GuidanceCategoryId =
  | 'fear-anxiety'
  | 'anger'
  | 'sadness-grief'
  | 'relationships'
  | 'family-problems'
  | 'patience'
  | 'forgiveness'
  | 'self-discipline'
  | 'purpose-of-life'
  | 'difficult-decisions';

export interface GuidanceCategory {
  id: GuidanceCategoryId;
  titleEn: string;
  titleHi: string;
  subtitleEn: string;
  subtitleHi: string;
  quranRefs: GuidanceReference[];
  gitaRefs: GuidanceReference[];
}

export interface OfflineStatus {
  quranCached: boolean;
  gitaCached: boolean;
  lastSyncedAt: number | null;
  quranSurahCount: number;
  quranVerseCount: number;
  gitaChapterCount: number;
  gitaVerseCount: number;
}

export interface ReaderTarget {
  scripture: ScriptureId;
  chapter: number;
  verse?: number;
}
