import type {GuidanceCategory} from '../types/scripture';

export const GUIDANCE_CATEGORIES: GuidanceCategory[] = [
  {
    id: 'fear-anxiety',
    titleEn: 'Fear and Anxiety',
    titleHi: 'भय और चिंता',
    subtitleEn: 'Finding steadiness when the heart feels overwhelmed by uncertainty.',
    subtitleHi: 'अनिश्चितता और व्याकुलता के समय मन को स्थिर रखने का मार्गदर्शन।',
    quranRefs: [
      {
        chapter: 94,
        verse: 5,
        reflectionEn: 'In Quranic teaching, hardship is accompanied by ease rather than standing alone as permanent despair.',
        reflectionHi: 'क़ुरआन की शिक्षा के अनुसार कठिनाई के साथ ही आसानी भी जुड़ी होती है; विपत्ति स्थायी नहीं होती।',
      },
      {
        chapter: 13,
        verse: 28,
        reflectionEn: 'Tranquility of the heart is linked to mindful remembrance of God rather than outward certainty.',
        reflectionHi: 'हृदय की शांति बाहरी परिस्थितियों से अधिक ईश्वर के स्मरण से प्राप्त होती है।',
      },
      {
        chapter: 2,
        verse: 286,
        reflectionEn: 'A core assurance that human capacity is never overburdened beyond what a soul can bear.',
        reflectionHi: 'यह आश्वासन कि किसी भी व्यक्ति पर उसकी सहन-शक्ति से अधिक बोझ नहीं डाला जाता।',
      },
    ],
    gitaRefs: [
      {
        chapter: 2,
        verse: 47,
        reflectionEn: 'Anxiety often grows from fixating on uncontrollable outcomes; the Gita directs attention to sincere action.',
        reflectionHi: 'चिंता प्रायः परिणामों की आसक्ति से जन्म लेती है; गीता निष्काम कर्म पर ध्यान केंद्रित करने का उपदेश देती है।',
      },
      {
        chapter: 2,
        verse: 14,
        reflectionEn: 'Pleasure and pain arise from sensory contact and are temporary like changing seasons, inviting inner endurance.',
        reflectionHi: 'सुख और दुःख मौसम की भाँति अस्थायी हैं; इन्हें धैर्यपूर्वक सहन करना स्थिरता सिखाता है।',
      },
      {
        chapter: 4,
        verse: 10,
        reflectionEn: 'Inner fear subsides as attachment recedes and understanding deepens through steady contemplation.',
        reflectionHi: 'आसक्ति से मुक्त होने और ज्ञान की परिपक्वता से भीतर का भय शांत होता है।',
      },
    ],
  },
  {
    id: 'anger',
    titleEn: 'Anger',
    titleHi: 'क्रोध',
    subtitleEn: 'Understanding the root of anger and practicing composed restraint.',
    subtitleHi: 'क्रोध की उत्पत्ति को समझना और संयम का अभ्यास करना।',
    quranRefs: [
      {
        chapter: 3,
        verse: 134,
        reflectionEn: 'Restraining anger and pardoning others is described as a defining trait of spiritual excellence.',
        reflectionHi: 'क्रोध को पी जाना और लोगों को क्षमा करना उच्च नैतिक चरित्र का लक्षण बताया गया है।',
      },
      {
        chapter: 41,
        verse: 34,
        reflectionEn: 'Responding to hostility with calm goodness can soften bitterness and transform strained relations.',
        reflectionHi: 'बुराई का उत्तर भलाई और संयम से देने से कटुता कम होती है और संबंध सुधर सकते हैं।',
      },
      {
        chapter: 42,
        verse: 37,
        reflectionEn: 'True strength is shown by forgiving even at the moment provocation sparks anger.',
        reflectionHi: 'क्रोध की स्थिति में भी क्षमा कर देना सच्चे आत्म-संयम का प्रमाण है।',
      },
    ],
    gitaRefs: [
      {
        chapter: 2,
        verse: 62,
        reflectionEn: 'The Gita traces anger back to unfulfilled desire born from mental attachment to objects.',
        reflectionHi: 'गीता के अनुसार विषयों के चिंतन से आसक्ति, आसक्ति से कामना और कामना में बाधा से क्रोध उत्पन्न होता है।',
      },
      {
        chapter: 2,
        verse: 63,
        reflectionEn: 'Following verse 2:62, this passage explains how unchecked anger clouds judgment and clarity of mind.',
        reflectionHi: 'श्लोक 2:62 के क्रम में यह बताता है कि अनियंत्रित क्रोध विवेक और स्मृति को नष्ट कर देता है।',
      },
      {
        chapter: 5,
        verse: 23,
        reflectionEn: 'Mastery over the sudden impulse of desire and anger here and now leads to lasting inner peace.',
        reflectionHi: 'जीवन में रहते हुए ही काम और क्रोध के वेग को सहन कर लेना वास्तविक शांति का मार्ग है।',
      },
    ],
  },
  {
    id: 'sadness-grief',
    titleEn: 'Sadness and Grief',
    titleHi: 'उदासी और शोक',
    subtitleEn: 'Holding sorrow gently without losing hope or perspective.',
    subtitleHi: 'गहरे दुःख के समय आशा और विवेक को संभाले रखना।',
    quranRefs: [
      {
        chapter: 2,
        verse: 153,
        reflectionEn: 'Believers are encouraged to seek steadiness through patient perseverance and prayer during trying times.',
        reflectionHi: 'कठिन परिस्थितियों में धैर्य और प्रार्थना के माध्यम से सहारा लेने की प्रेरणा दी गई है।',
      },
      {
        chapter: 93,
        verse: 3,
        reflectionEn: 'Revealed during a period of emotional heaviness, affirming that feeling forsaken does not mean abandonment.',
        reflectionHi: 'निराशा के क्षणों में यह स्मरण दिलाता है कि ईश्वर ने अपने बंदे को अकेला नहीं छोड़ा है।',
      },
      {
        chapter: 12,
        verse: 86,
        reflectionEn: 'Prophet Jacob voices raw grief directly to God rather than suppressing sorrow or losing hope.',
        reflectionHi: 'पैग़म्बर याक़ूब अपना गहरा शोक सीधे ईश्वर के समक्ष रखते हैं, बिना आशा खोए।',
      },
    ],
    gitaRefs: [
      {
        chapter: 2,
        verse: 11,
        reflectionEn: 'Spoken to Arjuna when grief paralyzed him, inviting wisdom over sorrow about what is impermanent.',
        reflectionHi: 'शोक से व्याकुल अर्जुन को यह बोध कराया गया कि जो नश्वर है उसके लिए असीम शोक उचित नहीं।',
      },
      {
        chapter: 2,
        verse: 27,
        reflectionEn: 'Acknowledges the inevitability of change and mortality so sorrow does not harden into despair.',
        reflectionHi: 'जन्म और मृत्यु की स्वाभाविक गति को स्वीकार करने से शोक की तीव्रता शांत होती है।',
      },
      {
        chapter: 6,
        verse: 22,
        reflectionEn: 'Describes a state of inner steadiness where even heavy sorrow cannot shake one’s center.',
        reflectionHi: 'आत्म-स्थिरता की उस अवस्था का वर्णन जहाँ बड़ा दुःख भी मन को विचलित नहीं कर पाता।',
      },
    ],
  },
  {
    id: 'relationships',
    titleEn: 'Relationships',
    titleHi: 'संबंध और व्यवहार',
    subtitleEn: 'Speaking kindly, guarding trust, and treating others with fairness.',
    subtitleHi: 'मधुर वाणी, आपसी सम्मान और करुणा के साथ संबंध निभाना।',
    quranRefs: [
      {
        chapter: 17,
        verse: 53,
        reflectionEn: 'Directs people to choose the gentlest, most constructive words in speech to prevent needless division.',
        reflectionHi: 'बातचीत में सदैव सबसे उत्तम और विनम्र शब्द चुनने का निर्देश ताकि कटुता न बढ़े।',
      },
      {
        chapter: 49,
        verse: 12,
        reflectionEn: 'Cautions against suspicion, spying, and backbiting, which quietly erode trust between people.',
        reflectionHi: 'अनावश्यक संदेह, टोह लेने और पीठ पीछे बुराई करने से बचने की सीख जो विश्वास को तोड़ती है।',
      },
      {
        chapter: 30,
        verse: 21,
        reflectionEn: 'Frames companionship, affection, and mercy as foundational signs within human bonds.',
        reflectionHi: 'मानवीय संबंधों में शांति, प्रेम और दया को प्रमुख आधार बताया गया है।',
      },
    ],
    gitaRefs: [
      {
        chapter: 12,
        verse: 13,
        reflectionEn: 'Presents non-hatred, friendliness, and compassion toward all beings as hallmarks of spiritual maturity.',
        reflectionHi: 'किसी से द्वेष न रखना तथा सभी प्राणियों के प्रति मैत्री और करुणा रखना श्रेष्ठ गुण है।',
      },
      {
        chapter: 6,
        verse: 32,
        reflectionEn: 'Encourages empathy—seeing the joy and sorrow of others as akin to one’s own.',
        reflectionHi: 'दूसरों के सुख और दुःख को अपने समान अनुभव करने की समदृष्टि सिखाता है।',
      },
      {
        chapter: 17,
        verse: 15,
        reflectionEn: 'Defines disciplined speech as truthful, gentle, beneficial, and free from needless agitation.',
        reflectionHi: 'सत्य, मधुर, हितकारी और उद्वेग न पैदा करने वाली वाणी को वाणी का तप कहा गया है।',
      },
    ],
  },
  {
    id: 'family-problems',
    titleEn: 'Family Problems',
    titleHi: 'पारिवारिक समस्याएँ',
    subtitleEn: 'Practicing gratitude toward parents, patience at home, and harmony.',
    subtitleHi: 'माता-पिता के प्रति सम्मान, धैर्य और घर में सौहार्द बनाए रखना।',
    quranRefs: [
      {
        chapter: 17,
        verse: 23,
        reflectionEn: 'Commands kindness toward parents, especially in old age, forbidding harsh words or impatience.',
        reflectionHi: 'माता-पिता के प्रति, विशेषकर वृद्धावस्था में, विनम्रता और सम्मान का स्पष्ट आदेश।',
      },
      {
        chapter: 64,
        verse: 14,
        reflectionEn: 'Acknowledges that tensions can arise even with spouses or children, urging pardon and forbearance.',
        reflectionHi: 'परिवार में मतभेद होने की संभावना को स्वीकार करते हुए क्षमा और सहनशीलता अपनाने की सलाह।',
      },
      {
        chapter: 25,
        verse: 74,
        reflectionEn: 'Models a prayer for households marked by comfort, integrity, and moral example.',
        reflectionHi: 'परिवार में शांति, सद्भाव और अच्छे आचरण की प्रार्थना का आदर्श प्रस्तुत करता है।',
      },
    ],
    gitaRefs: [
      {
        chapter: 16,
        verse: 2,
        reflectionEn: 'Cultivating non-violence, truthfulness, absence of anger, and compassion supports harmony at home.',
        reflectionHi: 'अहिंसा, सत्य, अक्रोध, शांति और दया जैसे गुण पारिवारिक तनाव को कम करने में सहायक हैं।',
      },
      {
        chapter: 16,
        verse: 3,
        reflectionEn: 'Highlights forgiveness, fortitude, and absence of pride when resolving domestic misunderstandings.',
        reflectionHi: 'क्षमा, धैर्य और अहंकार से दूरी पारिवारिक उलझनों को सुलझाने के लिए आवश्यक हैं।',
      },
      {
        chapter: 12,
        verse: 15,
        reflectionEn: 'Encourages remaining composed and non-reactive so household friction does not escalate.',
        reflectionHi: 'स्वयं शांत रहना और दूसरों को उद्वेलित न करना घर के वातावरण को संतुलित रखता है।',
      },
    ],
  },
  {
    id: 'patience',
    titleEn: 'Patience',
    titleHi: 'धैर्य और सहनशीलता',
    subtitleEn: 'Enduring delays and trials with dignity and perseverance.',
    subtitleHi: 'कठिन समय और प्रतीक्षा में गरिमा और धैर्य बनाए रखना।',
    quranRefs: [
      {
        chapter: 11,
        verse: 115,
        reflectionEn: 'Assures that steadfastness and sincere good conduct are never wasted.',
        reflectionHi: 'यह विश्वास दिलाता है कि धैर्य और नेक कर्म का प्रतिफल कभी व्यर्थ नहीं जाता।',
      },
      {
        chapter: 2,
        verse: 45,
        reflectionEn: 'Pairs active patience with prayer as practical anchors during demanding seasons of life.',
        reflectionHi: 'जीवन की कठिन घड़ियों में धैर्य और प्रार्थना को दृढ़ सहारा बताया गया है।',
      },
      {
        chapter: 103,
        verse: 3,
        reflectionEn: 'Reminds communities to encourage one another toward both truth and patient perseverance.',
        reflectionHi: 'आपस में सत्य और धैर्य की निरंतर प्रेरणा देते रहने का संदेश देता है।',
      },
    ],
    gitaRefs: [
      {
        chapter: 18,
        verse: 33,
        reflectionEn: 'Defines steady fortitude (dhriti) as the calm discipline that holds mind and senses balanced.',
        reflectionHi: 'सात्त्विक धैर्य वह स्थिरता है जो मन, प्राण और इंद्रियों को संतुलित रखती है।',
      },
      {
        chapter: 6,
        verse: 25,
        reflectionEn: 'Counsels gradual, patient steadying of the mind rather than expecting instant transformation.',
        reflectionHi: 'मन को धीरे-धीरे धैर्यपूर्वक स्थिर करने की व्यावहारिक विधि बताता है।',
      },
      {
        chapter: 13,
        verse: 7,
        reflectionEn: 'Lists forbearance and steadfastness among the foundational qualities of genuine wisdom.',
        reflectionHi: 'सहनशीलता और स्थिरता को सच्चे ज्ञान के प्रमुख अंगों में गिना गया है।',
      },
    ],
  },
  {
    id: 'forgiveness',
    titleEn: 'Forgiveness',
    titleHi: 'क्षमा',
    subtitleEn: 'Releasing resentment and choosing reconciliation where possible.',
    subtitleHi: 'मन की कड़वाहट त्यागना और क्षमा का मार्ग चुनना।',
    quranRefs: [
      {
        chapter: 42,
        verse: 40,
        reflectionEn: 'While proportional justice is permitted, pardoning and seeking reconciliation is held in higher honor.',
        reflectionHi: 'बदले के अधिकार के होते हुए भी क्षमा करना और सुलह की पहल करना अधिक श्रेष्ठ माना गया है।',
      },
      {
        chapter: 24,
        verse: 22,
        reflectionEn: 'Encourages overlooking faults and remaining generous even after personal hurt.',
        reflectionHi: 'व्यक्तिगत ठेस के बाद भी दोषों को क्षमा करने और उदार बने रहने की प्रेरणा देता है।',
      },
      {
        chapter: 7,
        verse: 199,
        reflectionEn: 'A direct instruction to hold fast to forgiveness, uphold goodness, and step back from provocation.',
        reflectionHi: 'क्षमा का मार्ग पकड़ने, भलाई को बढ़ावा देने और व्यर्थ विवाद से दूर रहने का निर्देश।',
      },
    ],
    gitaRefs: [
      {
        chapter: 16,
        verse: 3,
        reflectionEn: 'Forgiveness (kshama) is named directly among the noble qualities that elevate character.',
        reflectionHi: 'क्षमा को दैवी और श्रेष्ठ मानवीय गुणों में स्पष्ट रूप से स्थान दिया गया है।',
      },
      {
        chapter: 12,
        verse: 13,
        reflectionEn: 'Forgiving disposition flows naturally from letting go of egoism and hostility.',
        reflectionHi: 'अहंकार और द्वेष के कम होने पर क्षमाशील स्वभाव स्वतः विकसित होता है।',
      },
      {
        chapter: 11,
        verse: 44,
        reflectionEn: 'Models humility in asking for forgiveness—comparing divine patience to a parent or friend.',
        reflectionHi: 'विनम्रतापूर्वक क्षमा याचना करने और करुणापूर्ण क्षमा का भाव दर्शाता है।',
      },
    ],
  },
  {
    id: 'self-discipline',
    titleEn: 'Self-Discipline',
    titleHi: 'आत्म-अनुशासन',
    subtitleEn: 'Governing impulses and building steady daily habits.',
    subtitleHi: 'इंद्रियों और इच्छाओं पर संयम तथा नियमित अभ्यास।',
    quranRefs: [
      {
        chapter: 79,
        verse: 40,
        reflectionEn: 'Honors mindful restraint over destructive impulses out of awareness of moral accountability.',
        reflectionHi: 'ईश्वर के प्रति उत्तरदायित्व के बोध से अपनी अवांछित इच्छाओं पर संयम रखने की सराहना करता है।',
      },
      {
        chapter: 29,
        verse: 69,
        reflectionEn: 'Links sincere inner struggle and consistent effort with receiving clearer guidance.',
        reflectionHi: 'सच्चे प्रयास और आत्म-संघर्ष को सही मार्ग की प्राप्ति से जोड़ता है।',
      },
      {
        chapter: 73,
        verse: 8,
        reflectionEn: 'Emphasizes dedicated daily remembrance and quiet inward focus.',
        reflectionHi: 'नियमित स्मरण और एकाग्र समर्पण के अभ्यास पर बल देता है।',
      },
    ],
    gitaRefs: [
      {
        chapter: 6,
        verse: 5,
        reflectionEn: 'Reminds each person of their responsibility to uplift themselves rather than letting discipline slip.',
        reflectionHi: 'मनुष्य को स्वयं अपना उद्धार करना चाहिए, अपने मन को नीचे नहीं गिरने देना चाहिए।',
      },
      {
        chapter: 6,
        verse: 35,
        reflectionEn: 'Acknowledges that the mind is restless, while teaching that practice (abhyasa) and detachment tame it.',
        reflectionHi: 'मन की चंचलता को स्वीकार करते हुए अभ्यास और वैराग्य द्वारा उसे वश में करने का मार्ग बताता है।',
      },
      {
        chapter: 2,
        verse: 64,
        reflectionEn: 'True freedom comes not from fleeing the world, but from engaging life with self-mastery.',
        reflectionHi: 'इंद्रियों के संयम और राग-द्वेष से मुक्ति द्वारा संसार में रहते हुए भी शांति संभव है।',
      },
    ],
  },
  {
    id: 'purpose-of-life',
    titleEn: 'Purpose of Life',
    titleHi: 'जीवन का उद्देश्य',
    subtitleEn: 'Seeking meaning through worship, service, and ethical responsibility.',
    subtitleHi: 'सार्थकता, कर्तव्य-पालन और नैतिक उत्तरदायित्व का बोध।',
    quranRefs: [
      {
        chapter: 67,
        verse: 2,
        reflectionEn: 'Explains life as a meaningful moral arena meant to reveal excellence in character and deeds.',
        reflectionHi: 'जीवन को अच्छे कर्मों और श्रेष्ठ आचरण की परीक्षा के रूप में अर्थपूर्ण बताता है।',
      },
      {
        chapter: 28,
        verse: 77,
        reflectionEn: 'Encourages balancing spiritual aspiration with responsible engagement and generosity in this world.',
        reflectionHi: 'आध्यात्मिक लक्ष्य के साथ इस संसार में अपने दायित्व और परोपकार में संतुलन रखने की सीख।',
      },
      {
        chapter: 2,
        verse: 148,
        reflectionEn: 'Calls people to strive earnestly with one another in doing good deeds wherever they are.',
        reflectionHi: 'जहाँ भी हों, नेकी और भलाई के कार्यों में आगे बढ़ने का आह्वान करता है।',
      },
    ],
    gitaRefs: [
      {
        chapter: 3,
        verse: 19,
        reflectionEn: 'Teaches that fulfilling one’s rightful work without selfish attachment leads toward higher realization.',
        reflectionHi: 'आसक्ति से रहित होकर अपने कर्तव्य कर्म का निरंतर पालन करना ही उत्कर्ष का मार्ग है।',
      },
      {
        chapter: 18,
        verse: 45,
        reflectionEn: 'Shows that spiritual fulfillment can be realized through wholehearted dedication to one’s vocation.',
        reflectionHi: 'अपने स्वाभाविक कर्म में निष्ठापूर्वक लगे रहकर भी मनुष्य सिद्धि प्राप्त कर सकता है।',
      },
      {
        chapter: 2,
        verse: 48,
        reflectionEn: 'Defines Yoga as evenness of mind in both success and failure while performing worthy action.',
        reflectionHi: 'सफलता और असफलता में समभाव रखकर कर्म करने को ही योग कहा गया है।',
      },
    ],
  },
  {
    id: 'difficult-decisions',
    titleEn: 'Difficult Decisions',
    titleHi: 'कठिन निर्णय',
    subtitleEn: 'Seeking counsel, reflecting carefully, and acting with integrity.',
    subtitleHi: 'परामर्श, गहन विचार और निष्ठा के साथ निर्णय लेना।',
    quranRefs: [
      {
        chapter: 3,
        verse: 159,
        reflectionEn: 'Combines mutual consultation with decisive resolve and trust once a course is chosen.',
        reflectionHi: 'कठिन मामलों में परामर्श करने और फिर दृढ़ निश्चय के साथ ईश्वर पर भरोसा रखने की शिक्षा।',
      },
      {
        chapter: 42,
        verse: 38,
        reflectionEn: 'Highlights conducting important matters through thoughtful mutual consultation.',
        reflectionHi: 'महत्वपूर्ण निर्णयों को आपसी विचार-विमर्श से तय करने को उत्तम आचरण बताया गया है।',
      },
      {
        chapter: 2,
        verse: 216,
        reflectionEn: 'Reminds readers that human foresight is limited; what feels difficult may hold unseen good.',
        reflectionHi: 'हमारी दृष्टि सीमित है; कभी-कभी कठिन प्रतीत होने वाला मार्ग ही दीर्घकाल में हितकारी होता है।',
      },
    ],
    gitaRefs: [
      {
        chapter: 2,
        verse: 7,
        reflectionEn: 'Models honest humility in admitting confusion and seeking trustworthy clarity before acting.',
        reflectionHi: 'भ्रम की स्थिति में अहंकार छोड़कर स्पष्ट मार्गदर्शन माँगने की विनम्रता को दर्शाता है।',
      },
      {
        chapter: 18,
        verse: 63,
        reflectionEn: 'After offering deep counsel, Krishna invites Arjuna to reflect fully and choose responsibly himself.',
        reflectionHi: 'संपूर्ण ज्ञान देने के बाद भी श्रीकृष्ण निर्णय की स्वतंत्रता स्वयं विचार कर चुनने पर छोड़ते हैं।',
      },
      {
        chapter: 18,
        verse: 47,
        reflectionEn: 'Counsels staying true to one’s authentic duty rather than imitating an ill-fitting path.',
        reflectionHi: 'दूसरों की नकल के बजाय अपने वास्तविक स्वधर्म और दायित्व पर टिके रहने का उपदेश।',
      },
    ],
  },
];
