import type {ScriptureId} from '../types/scripture';

export interface DailyWisdomSeed {
  scripture: ScriptureId;
  chapter: number;
  verse: number;
  reflectionEn: string;
  reflectionHi: string;
}

export const DAILY_WISDOM_SEEDS: DailyWisdomSeed[] = [
  {
    scripture: 'quran',
    chapter: 94,
    verse: 5,
    reflectionEn: 'Pause and remember that hardship never arrives without relief woven beside it.',
    reflectionHi: 'यह स्मरण रखें कि कठिनाई के साथ ही सहजता और राहत भी जुड़ी होती है।',
  },
  {
    scripture: 'gita',
    chapter: 2,
    verse: 47,
    reflectionEn: 'Invest your sincerity in today’s effort; release anxiety over outcomes beyond your hand.',
    reflectionHi: 'अपना पूरा ध्यान आज के कर्तव्य पर रखें; परिणाम की चिंता को शांत भाव से छोड़ दें।',
  },
  {
    scripture: 'quran',
    chapter: 13,
    verse: 28,
    reflectionEn: 'Quiet remembrance restores steadiness when external circumstances feel unsettled.',
    reflectionHi: 'जब बाहरी स्थितियाँ अस्थिर हों, तब शांत स्मरण हृदय को स्थिरता प्रदान करता है।',
  },
  {
    scripture: 'gita',
    chapter: 6,
    verse: 5,
    reflectionEn: 'Be a steady friend to your own mind through small, deliberate acts of self-respect.',
    reflectionHi: 'नियमित आत्म-संयम और छोटे सार्थक कदमों से स्वयं अपने मन के मित्र बनें।',
  },
  {
    scripture: 'quran',
    chapter: 3,
    verse: 134,
    reflectionEn: 'Strength shows most clearly in restraining anger and extending grace.',
    reflectionHi: 'सच्ची शक्ति क्रोध पर नियंत्रण रखने और दूसरों को क्षमा करने में प्रकट होती है।',
  },
  {
    scripture: 'gita',
    chapter: 12,
    verse: 13,
    reflectionEn: 'Meet today without ill-will—carrying friendliness and quiet compassion toward all.',
    reflectionHi: 'द्वेष से मुक्त होकर आज का दिन सभी के प्रति मैत्री और करुणा के साथ बिताएँ।',
  },
  {
    scripture: 'quran',
    chapter: 2,
    verse: 286,
    reflectionEn: 'Take one honest step forward; you are not asked to carry more than your measure.',
    reflectionHi: 'एक ईमानदार कदम आगे बढ़ाएँ; आपसे आपकी क्षमता से अधिक की अपेक्षा नहीं है।',
  },
  {
    scripture: 'gita',
    chapter: 2,
    verse: 48,
    reflectionEn: 'True steadiness lies in keeping an even mind amidst both praise and setback.',
    reflectionHi: 'सफलता और असफलता दोनों में मन का संतुलन बनाए रखना ही सच्ची स्थिरता है।',
  },
];

export function getDailyWisdomIndex(offset = 0): number {
  const now = new Date();
  const start = new Date(now.getFullYear(), 0, 0);
  const diff = now.getTime() - start.getTime();
  const dayOfYear = Math.floor(diff / (1000 * 60 * 60 * 24));
  const len = DAILY_WISDOM_SEEDS.length;
  return (((dayOfYear + offset) % len) + len) % len;
}
