// Capacitor Android APK configuration for RELIEF
// To package an Android APK:
// 1. npm run build
// 2. npm install @capacitor/core @capacitor/cli @capacitor/android
// 3. npx cap add android && npx cap sync android
// 4. npx cap open android (or cd android && ./gradlew assembleRelease)

const config = {
  appId: 'app.relief.scripture',
  appName: 'RELIEF',
  webDir: 'dist',
  bundledWebRuntime: false,
  server: {
    androidScheme: 'https',
  },
  android: {
    backgroundColor: '#111214',
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: false,
  },
};

export default config;
