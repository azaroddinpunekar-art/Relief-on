import fs from 'fs';
import path from 'path';

const OUT_DIR = path.resolve('public/data');

async function main() {
  console.log('Fetching Holy Quran metadata & editions...');
  const [qInfo, qEn, qHi] = await Promise.all([
    fetch('https://cdn.jsdelivr.net/gh/fawazahmed0/quran-api@1/info.json').then(r => r.json()),
    fetch('https://cdn.jsdelivr.net/gh/fawazahmed0/quran-api@1/editions/eng-mustafakhattaba.json').then(r => r.json()),
    fetch('https://cdn.jsdelivr.net/gh/fawazahmed0/quran-api@1/editions/hin-muhammadfarooqk.json').then(r => r.json()),
  ]);

  const surahs = qInfo.chapters.map(c => ({
    number: c.chapter,
    name: c.name,
    englishName: c.englishname,
    revelationPlace: c.revelation,
    versesCount: c.verses.length,
  }));

  const quranEn = qEn.quran.map(v => ({
    s: v.chapter,
    v: v.verse,
    t: v.text.trim(),
  }));

  const quranHi = qHi.quran.map(v => ({
    s: v.chapter,
    v: v.verse,
    t: v.text.trim(),
  }));

  if (surahs.length !== 114) throw new Error(`Expected 114 surahs, got ${surahs.length}`);
  if (quranEn.length !== 6236) throw new Error(`Expected 6236 Quran EN verses, got ${quranEn.length}`);
  if (quranHi.length !== 6236) throw new Error(`Expected 6236 Quran HI verses, got ${quranHi.length}`);

  const emptyQEn = quranEn.filter(x => !x.t).length;
  const emptyQHi = quranHi.filter(x => !x.t).length;
  if (emptyQEn || emptyQHi) throw new Error(`Empty Quran translations: EN=${emptyQEn}, HI=${emptyQHi}`);

  console.log('Fetching Bhagavad Gita metadata & translations...');
  const [gChaptersRaw, gVersesRaw, gTransRaw] = await Promise.all([
    fetch('https://raw.githubusercontent.com/gita/gita/main/data/chapters.json').then(r => r.json()),
    fetch('https://raw.githubusercontent.com/gita/gita/main/data/verse.json').then(r => r.json()),
    fetch('https://raw.githubusercontent.com/gita/gita/main/data/translation.json').then(r => r.json()),
  ]);

  const enMap = new Map();
  const hiMap = new Map();
  for (const tr of gTransRaw) {
    if (tr.lang === 'english' && tr.authorName === 'Swami Sivananda') {
      enMap.set(tr.verse_id, tr.description.replace(/\s+/g, ' ').trim());
    }
    if (tr.lang === 'hindi' && tr.authorName === 'Swami Tejomayananda') {
      // Remove leading ।।ch.v।। prefix if present
      const cleaned = tr.description
        .replace(/^[\s\u0964\u0965|]*\d+\.\d+[\s\u0964\u0965|]*/u, '')
        .replace(/\s+/g, ' ')
        .trim();
      hiMap.set(tr.verse_id, cleaned);
    }
  }

  // Standardize Chapter 13 to 34 verses (total 700 verses across 18 chapters):
  // Preserve Arjuna's introductory question (raw 13.1) as part of verse 13.1 before Lord Krishna's reply (raw 13.2),
  // and map raw 13.2..13.35 -> 13.1..13.34.
  const gitaEn = [];
  const gitaHi = [];
  let c13IntroEn = '';
  let c13IntroHi = '';

  for (const v of gVersesRaw) {
    const enText = enMap.get(v.id);
    const hiText = hiMap.get(v.id);
    if (!enText || !hiText) {
      throw new Error(`Missing Gita translation for verse id=${v.id} (${v.chapter_number}.${v.verse_number})`);
    }
    if (v.chapter_number === 13 && v.verse_number === 1) {
      c13IntroEn = enText;
      c13IntroHi = hiText;
      continue;
    }
    let verseNum = v.verse_number;
    let finalEn = enText;
    let finalHi = hiText;
    if (v.chapter_number === 13) {
      verseNum = v.verse_number - 1;
      if (verseNum === 1) {
        finalEn = `${c13IntroEn} ${enText}`;
        finalHi = `${c13IntroHi} ${hiText}`;
      }
    }
    gitaEn.push({ c: v.chapter_number, v: verseNum, t: finalEn });
    gitaHi.push({ c: v.chapter_number, v: verseNum, t: finalHi });
  }

  const gitaChapters = gChaptersRaw.map(c => ({
    number: c.chapter_number,
    nameTransliterated: c.name_translation,
    nameMeaningEn: c.name_meaning,
    summaryEn: c.chapter_summary.replace(/\s+/g, ' ').trim(),
    summaryHi: c.chapter_summary_hindi.replace(/\s+/g, ' ').trim(),
    versesCount: c.chapter_number === 13 ? 34 : c.verses_count,
  }));

  if (gitaChapters.length !== 18) throw new Error(`Expected 18 Gita chapters, got ${gitaChapters.length}`);
  if (gitaEn.length !== 700) throw new Error(`Expected 700 Gita EN verses, got ${gitaEn.length}`);
  if (gitaHi.length !== 700) throw new Error(`Expected 700 Gita HI verses, got ${gitaHi.length}`);

  fs.writeFileSync(path.join(OUT_DIR, 'quran_surahs.json'), JSON.stringify(surahs));
  fs.writeFileSync(path.join(OUT_DIR, 'quran_en.json'), JSON.stringify(quranEn));
  fs.writeFileSync(path.join(OUT_DIR, 'quran_hi.json'), JSON.stringify(quranHi));
  fs.writeFileSync(path.join(OUT_DIR, 'gita_chapters.json'), JSON.stringify(gitaChapters));
  fs.writeFileSync(path.join(OUT_DIR, 'gita_en.json'), JSON.stringify(gitaEn));
  fs.writeFileSync(path.join(OUT_DIR, 'gita_hi.json'), JSON.stringify(gitaHi));

  console.log('SUCCESS! Verified counts:');
  console.log({
    quranSurahs: surahs.length,
    quranVersesEn: quranEn.length,
    quranVersesHi: quranHi.length,
    gitaChapters: gitaChapters.length,
    gitaVersesEn: gitaEn.length,
    gitaVersesHi: gitaHi.length,
  });
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
