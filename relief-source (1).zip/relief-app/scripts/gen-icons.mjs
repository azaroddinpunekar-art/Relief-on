import fs from 'fs';
import zlib from 'zlib';

// Minimal deterministic RGBA PNG generator for crisp vector-rasterized RELIEF app icons
function crc32(buf) {
  let c = -1;
  for (let i = 0; i < buf.length; i++) {
    c = (c >>> 8) ^ crcTable[(c ^ buf[i]) & 0xff];
  }
  return (c ^ -1) >>> 0;
}
const crcTable = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
  crcTable[n] = c;
}

function makeChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const t = Buffer.from(type, 'ascii');
  const crcBuf = Buffer.concat([t, data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(crcBuf), 0);
  return Buffer.concat([len, t, data, crc]);
}

function encodePng(width, height, rgba) {
  const raw = Buffer.alloc((width * 4 + 1) * height);
  for (let y = 0; y < height; y++) {
    raw[y * (width * 4 + 1)] = 0;
    rgba.copy(raw, y * (width * 4 + 1) + 1, y * width * 4, (y + 1) * width * 4);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // RGBA
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;
  const idat = zlib.deflateSync(raw, { level: 9 });
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    makeChunk('IHDR', ihdr),
    makeChunk('IDAT', idat),
    makeChunk('IEND', Buffer.alloc(0)),
  ]);
}

function drawReliefIcon(size, maskable = false) {
  const buf = Buffer.alloc(size * size * 4);
  const bg = [17, 18, 20, 255]; // #111214
  const gold = [201, 169, 110, 255]; // #C9A96E
  const ivory = [229, 222, 201, 255]; // #E5DEC9

  const scale = maskable ? 0.68 : 0.84;
  const cx = size / 2;
  const cy = size / 2;

  function setPixel(x, y, col, alpha = 1) {
    if (x < 0 || y < 0 || x >= size || y >= size) return;
    const idx = (y * size + x) * 4;
    const a = alpha * (col[3] / 255);
    buf[idx] = Math.round(buf[idx] * (1 - a) + col[0] * a);
    buf[idx + 1] = Math.round(buf[idx + 1] * (1 - a) + col[1] * a);
    buf[idx + 2] = Math.round(buf[idx + 2] * (1 - a) + col[2] * a);
    buf[idx + 3] = 255;
  }

  // Fill background
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = (y * size + x) * 4;
      buf[idx] = bg[0];
      buf[idx + 1] = bg[1];
      buf[idx + 2] = bg[2];
      buf[idx + 3] = 255;
    }
  }

  // Draw refined geometric twin-arch emblem + central sun/seed
  const u = (size * scale) / 512;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const nx = (x - cx) / u + 256;
      const ny = (y - cy) / u + 256;

      // Subtle outer frame ring for non-maskable
      if (!maskable) {
        const dx = Math.abs(nx - 256);
        const dy = Math.abs(ny - 256);
        const dBox = Math.max(dx, dy);
        if (dBox > 224 && dBox < 228) {
          setPixel(x, y, gold, 0.35);
        }
      }

      // Central golden orb
      const distOrb = Math.hypot(nx - 256, ny - 196);
      if (distOrb <= 24) {
        const aa = Math.min(1, Math.max(0, 24 - distOrb + 0.5));
        setPixel(x, y, gold, aa);
      }

      // Twin open pages / sanctuary arches
      const stroke = 13;
      // Left arch top
      if (ny <= 202 && nx >= 146 && nx <= 256) {
        const d = Math.abs(Math.hypot(nx - 201, ny - 202) - 55);
        if (d < stroke / 2) setPixel(x, y, gold, 1);
      }
      // Right arch top
      if (ny <= 202 && nx >= 256 && nx <= 366) {
        const d = Math.abs(Math.hypot(nx - 311, ny - 202) - 55);
        if (d < stroke / 2) setPixel(x, y, gold, 1);
      }
      // Vertical spines (left, center, right)
      if (ny >= 202 && ny <= 378) {
        if (Math.abs(nx - 146) < stroke / 2) setPixel(x, y, gold, 1);
        if (Math.abs(nx - 256) < stroke / 2) setPixel(x, y, gold, 1);
        if (Math.abs(nx - 366) < stroke / 2) setPixel(x, y, gold, 1);
      }
      // Base horizontal line
      if (nx >= 146 && nx <= 366 && Math.abs(ny - 378) < stroke / 2) {
        setPixel(x, y, gold, 1);
      }
      // Subtle scripture lines
      if ((Math.abs(ny - 278) < 5 || Math.abs(ny - 322) < 5) && ((nx >= 178 && nx <= 228) || (nx >= 284 && nx <= 334))) {
        setPixel(x, y, ivory, 0.85);
      }
    }
  }

  return encodePng(size, size, buf);
}

fs.writeFileSync('public/pwa-192x192.png', drawReliefIcon(192, false));
fs.writeFileSync('public/pwa-512x512.png', drawReliefIcon(512, false));
fs.writeFileSync('public/pwa-maskable-512x512.png', drawReliefIcon(512, true));
fs.writeFileSync('public/apple-touch-icon.png', drawReliefIcon(180, false));
console.log('Generated PNG icons cleanly.');
